#!/bin/bash

echo "========================================"
echo "MATSim Lagos Traffic Simulation Runner"
echo "========================================"
echo

# Check if Maven is installed
if ! command -v mvn &> /dev/null; then
    echo "Error: Maven is not installed or not in PATH"
    echo "Please install Maven from https://maven.apache.org/"
    exit 1
fi

# Check if Java is installed
if ! command -v java &> /dev/null; then
    echo "Error: Java is not installed or not in PATH"
    echo "Please install Java 11 or higher"
    exit 1
fi

echo "Building project..."
mvn clean compile
if [ $? -ne 0 ]; then
    echo "Build failed!"
    exit 1
fi

echo
echo "Packaging application..."
mvn package
if [ $? -ne 0 ]; then
    echo "Packaging failed!"
    exit 1
fi

echo
echo "========================================"
echo "Starting MATSim Lagos Simulation"
echo "========================================"
echo "Configuration:"
echo "- Agents: 1000 (default)"
echo "- Iterations: 10 (default)"
echo "- Output: output/lagos-simulation"
echo "========================================"
echo

# Run the simulation with default parameters
java -Xmx2G -jar target/matsim-lagos-app-1.0.0-jar-with-dependencies.jar

echo
echo "========================================"
echo "Simulation Complete!"
echo "Check output/lagos-simulation for results"
echo "========================================"