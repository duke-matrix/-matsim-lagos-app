# GitHub Deployment Guide for MATSim Lagos Application

This guide provides step-by-step instructions for deploying the `matsim-lagos-app` to GitHub, including repository initialization, code push, and setting up Continuous Integration/Continuous Deployment (CI/CD) using GitHub Actions.

## 1. Initialize a Git Repository

First, navigate to the root directory of your `matsim-lagos-app` project and initialize a new Git repository:

```bash
cd matsim-lagos-app
git init
```

## 2. Add Files to the Repository

Add all relevant project files to the Git staging area. It's crucial to ensure that sensitive information or unnecessary large files (e.g., `target/` directories, large datasets that are not part of the core repo) are excluded using a `.gitignore` file. A basic `.gitignore` for this project might look like this:

```
# Java
*.class
*.jar
*.war
*.ear
*.zip
*.tar.gz
/target/

# Maven
.mvn/
mvnw
mvnw.cmd

# Python
__pycache__/
*.pyc
.venv/
virtualenv/
venv/

# Logs and output
*.log
logs/
output/

# IDEs
.idea/
.vscode/
*.iml

# Operating System
.DS_Store
Thumbs.db
```

Create or update the `.gitignore` file:

```bash
echo -e "# Java\n*.class\n*.jar\n*.war\n*.ear\n*.zip\n*.tar.gz\n/target/\n\n# Maven\n.mvn/\nmvnw\nmvnw.cmd\n\n# Python\n__pycache__/\n*.pyc\n.venv/\nvirtualenv/\nvenv/\n\n# Logs and output\n*.log\nlogs/\noutput/\n\n# IDEs\n.idea/\n.vscode/\n*.iml\n\n# Operating System\n.DS_Store\nThumbs.db" > .gitignore
```

Now, add all files to the staging area:

```bash
git add .
```

## 3. Commit Changes

Commit the staged changes to your local repository with a descriptive message:

```bash
git commit -m "Initial commit: Refactored MATSim Lagos App for GitHub deployment"
```

## 4. Create a GitHub Repository

1.  Go to [GitHub](https://github.com/) and log in to your account.
2.  Click the `+` sign in the top right corner and select `New repository`.
3.  Give your repository a name (e.g., `matsim-lagos-app`).
4.  Add a brief description.
5.  Choose `Public` or `Private` based on your preference.
6.  **Do NOT** initialize the repository with a README, .gitignore, or license, as you've already created these locally.
7.  Click `Create repository`.

## 5. Link Local Repository to GitHub and Push Code

After creating the remote repository on GitHub, you will be provided with commands to link your local repository. Typically, these commands look like this (replace `YOUR_USERNAME` and `YOUR_REPOSITORY_NAME` with your actual GitHub username and repository name):

```bash
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY_NAME.git
git branch -M main
git push -u origin main
```

This will push your local `main` branch to the `origin` (your GitHub repository).

## 6. Verify Repository Structure on GitHub

After pushing, refresh your GitHub repository page. You should see the new structure:

```
matsim-lagos-app/
├── .github/
│   └── workflows/
│       └── ci.yml
├── java-matsim-core/
├── python-api-dashboard/
├── Dockerfile
├── docker-entrypoint.sh
├── LICENSE
├── README.md
└── TEST_PLAN.md
```

## 7. Configure GitHub Actions for CI/CD

The `ci.yml` file you created (`.github/workflows/ci.yml`) is already configured for automated build, test, Docker build, and a smoke test. Once pushed to GitHub, this workflow will automatically trigger on every `push` to the `main` branch and on every `pull_request` targeting `main`.

To view the status of your CI/CD pipeline:

1.  Navigate to your repository on GitHub.
2.  Click on the `Actions` tab.
3.  You should see a workflow run triggered by your `git push` operation.
4.  Click on the workflow run to view its progress and detailed logs for each step (checkout, Java build, Python tests, Docker build, smoke test).

### Troubleshooting CI/CD

*   **Workflow not triggering:** Ensure the `ci.yml` file is correctly placed in `.github/workflows/` and has the correct `on:` triggers.
*   **Build failures:** Review the logs in the GitHub Actions interface. Common issues include missing dependencies, incorrect paths, or test failures.
*   **Docker build issues:** Check the Dockerfile for syntax errors or issues with copying files between stages.
*   **Smoke test failures:** Verify that the services inside the Docker container are starting correctly and are accessible on the expected ports.

By following these steps, your `matsim-lagos-app` will be successfully deployed to GitHub with an automated CI/CD pipeline, ensuring code quality and deployment readiness.
