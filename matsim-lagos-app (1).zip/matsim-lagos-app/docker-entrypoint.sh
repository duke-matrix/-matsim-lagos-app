#!/bin/bash

# Placeholder for starting the Java MATSim application if it's a long-running server.
# If the Java application is a one-time simulation, it should be run as part of the CI/CD or separately.
# For now, we assume the Python dashboard is the primary long-running process.
# java -jar /app/java-matsim-core/matsim-lagos-app.jar &

echo "Starting Python Web Dashboard..."
cd /app/python-api-dashboard
python3 web_dashboard.py &

# Keep the container running by waiting for background processes
wait -n
exit $?

