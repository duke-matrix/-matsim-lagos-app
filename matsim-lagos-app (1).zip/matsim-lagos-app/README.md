# MATSim Lagos Application

This repository contains the MATSim-based simulation for Lagos, Nigeria, along with a Python API and dashboard for interacting with and visualizing simulation results. The project is structured to separate the core Java MATSim simulation logic from the Python-based API and web dashboard.

## Project Overview

The MATSim Lagos Application aims to model and analyze urban mobility patterns in Lagos, Nigeria, using the Multi-Agent Transport Simulation (MATSim) framework. It provides insights into traffic congestion, travel times, modal split, and environmental impacts. The Python components offer a flexible interface for running simulations, processing outputs, and visualizing data through a web-based dashboard.

## Features

*   **MATSim Core Simulation:** Detailed agent-based transport simulation of Lagos.
*   **Python API:** Programmatic access to simulation control and data retrieval.
*   **Web Dashboard:** Interactive visualization of simulation outputs and key metrics.
*   **Docker Support:** Containerized deployment for reproducible environments.
*   **CI/CD Integration:** Automated build, test, and deployment workflows.

## Project Structure

```
matsim-lagos-app/
├── java-matsim-core/          # MATSim Java project (core simulation logic)
│   ├── pom.xml                # Maven project file
│   ├── src/                   # Java source code
│   ├── config/                # Simulation configuration files
│   ├── data/                  # Input data for simulations (network, population)
│   ├── output/                # Simulation output files
│   └── run-simulation.sh      # Script to run the Java simulation
├── python-api-dashboard/      # Python project (API and web dashboard)
│   ├── api/                   # Python API source code
│   ├── web_dashboard.py       # Flask web dashboard application
│   ├── requirements.txt       # Python dependencies
│   └── tests/                 # Python unit and integration tests
├── .github/                   # GitHub Actions workflows
├── Dockerfile                 # Docker build instructions
├── LICENSE                    # Project license (MIT)
└── README.md                  # This README file
```

## Quickstart

### Prerequisites

*   Java Development Kit (JDK) 11 or higher (for Java MATSim core)
*   Apache Maven (for Java MATSim core)
*   Python 3.8 or higher (for Python API and dashboard)
*   pip (Python package installer)
*   Docker (for containerized deployment)

### 1. Java MATSim Core

To build and run the MATSim simulation:

```bash
cd java-matsim-core
mvn clean install
./run-simulation.sh # This script will likely need arguments or configuration
```

Refer to `java-matsim-core/run-simulation.sh` and `java-matsim-core/config/` for specific simulation configurations.

### 2. Python API and Dashboard

To set up and run the Python components:

```bash
cd python-api-dashboard
pip install -r requirements.txt

# Run the API (example using Flask development server)
# python -m api.traffic_api # Adjust based on actual API entry point

# Run the Web Dashboard
python web_dashboard.py
```

### 3. Docker

To build and run the entire application using Docker:

```bash
# Build the Docker image
docker build -t matsim-lagos-app .

# Run the Docker container
docker run -p 5000:5000 -p 8080:8080 matsim-lagos-app
# Adjust port mappings as necessary for your API and dashboard
```

This will build a multi-stage Docker image that includes both the compiled Java MATSim application and the Python API/dashboard, ready for execution.

## Lagos-Specific Features

### Transit System
- **BRT Lines**: CMS-Mile2, Oshodi-Victoria Island
- **Danfo Routes**: Yaba-Surulere, Ikeja-Agege, Apapa-Marina

### Traffic Patterns
- Morning Peak (7-10 AM): 2.5x congestion
- Evening Peak (5-8 PM): 2.8x congestion
- Midday: 1.5x congestion

### Agent Activities
```
Home → Work → [Market] → [School] → Home
```

## Compression Spec Mapping

| Symbol | Component | Implementation | Description |
|--------|-----------|----------------|-------------|
| **Ω** | OSM→Network | `NetworkBuilder.java` | Converts OpenStreetMap data to MATSim network |
| **Δ** | Population{hwms} | `PopulationBuilder.java` | Generates agents with home→work→market→school activities |
| **M** | Modes{cbw} | Multiple classes | Car, Bus (PT), Walk transport modes |
| **τ** | Transit[BRT,df] | `TransitBuilder.java` | BRT lines + Danfo (informal transit) routes |
| **C** | Configuration | `SimulationRunner.java` | MATSim config with iterations and parameters |
| **Σ** | Output{t,ms,σ} | `ResultsAnalyzer.java` | Travel times, modal split, agent scores |
| **ν** | Visualization | `ResultsAnalyzer.java` | Summary reports and statistics |
| **13** | Version | `pom.xml` | MATSim 13.0 |
| **M⁷** | Modular | 7 classes | Clean modular architecture |

## Contributing

Contributions are welcome! Please refer to `CONTRIBUTING.md` (if available) for guidelines.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

