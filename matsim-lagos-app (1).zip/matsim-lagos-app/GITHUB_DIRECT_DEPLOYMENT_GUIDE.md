 to manually select them.
    *   **Important:** You will need to upload files and folders recursively. For example, first upload the contents of `.github/workflows/`, then `java-matsim-core/`, etc. Alternatively, you can zip your entire `matsim-lagos-app` folder (excluding `.git` and `target` directories) and upload the zip file. GitHub will usually unpack it correctly.
2.  **Commit Changes:** After uploading, provide a commit message (e.g., "Initial commit of refactored MATSim Lagos App") and click `Commit changes`.

## 4. Verify Repository Structure

Once the upload is complete, navigate to the `Code` tab of your new GitHub repository. You should see the refactored project structure:

```
matsim-lagos-app/
├── .github/
│   └── workflows/
│       └── ci.yml
├── java-matsim-core/
├── python-api-dashboard/
├── Dockerfile
├── docker-entrypoint.sh
├── LICENSE
├── README.md
└── TEST_PLAN.md
```

## 5. Configure GitHub Actions (CI/CD)

The `ci.yml` file located in `.github/workflows/` is already configured to set up Continuous Integration/Continuous Deployment (CI/CD) for your project. This workflow will automatically trigger on every `push` to the `main` branch and on every `pull_request` targeting `main`.

To monitor your CI/CD pipeline:

1.  In your GitHub repository, click on the `Actions` tab.
2.  You should see a workflow run triggered by your file upload. Click on it to view the progress and detailed logs for each step (e.g., Java build, Python tests, Docker build, smoke test).

### Troubleshooting CI/CD

*   **Workflow not triggering:** Ensure the `ci.yml` file is correctly placed in the `.github/workflows/` directory within your repository.
*   **Build failures:** Examine the logs in the GitHub Actions interface. Common issues include missing dependencies, incorrect file paths, or test failures.
*   **Docker build issues:** Check the `Dockerfile` for syntax errors or problems with copying files between stages.
*   **Smoke test failures:** Verify that the services inside the Docker container are starting correctly and are accessible on the expected ports.

By following these steps, your `matsim-lagos-app` will be successfully deployed to GitHub, and its automated CI/CD pipeline will be active, ensuring continuous code quality and deployment readiness.
