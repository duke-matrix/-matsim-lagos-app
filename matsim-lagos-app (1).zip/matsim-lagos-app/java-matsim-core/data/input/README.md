# Input Data Directory

This directory contains input data files for the Lagos Traffic Simulation.

## Expected Files

### Required Files
- `lagos.osm` - OpenStreetMap data for Lagos
- `population.csv` - Population demographics data
- `transit_routes.json` - BRT and Danfo route definitions
- `traffic_patterns.csv` - Historical traffic patterns

### Optional Files
- `weather_data.json` - Weather conditions data
- `events_calendar.csv` - Major events affecting traffic
- `fuel_stations.geojson` - Fuel station locations
- `incidents_history.csv` - Historical incident data

## Data Formats

### Population CSV Format
```csv
agent_id,home_lat,home_lon,work_lat,work_lon,mode,departure_time
1,6.5244,3.3792,6.4531,3.3965,car,07:30
2,6.5512,3.3454,6.4281,3.4247,danfo,06:45
```

### Transit Routes JSON Format
```json
{
  "routes": [
    {
      "id": "BRT1",
      "name": "CMS to Mile 2",
      "stops": ["CMS", "National Theatre", "Mile 2"],
      "frequency": 15
    }
  ]
}
```

## Data Sources
- OpenStreetMap: https://www.openstreetmap.org/
- Lagos Bureau of Statistics: https://lagos.gov.ng/
- LAMATA: https://lamata.lagosstate.gov.ng/