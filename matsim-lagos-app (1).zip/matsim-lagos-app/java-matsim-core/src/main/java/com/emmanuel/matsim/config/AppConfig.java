package com.emmanuel.matsim.config;

import java.io.*;
import java.util.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Central configuration manager for MATSim Lagos
 */
public class AppConfig {
    private static final Logger log = LogManager.getLogger(AppConfig.class);
    private static AppConfig instance;
    private Properties props = new Properties();
    private Map<String, String> cliOverrides = new HashMap<>();
    
    private AppConfig() {
        loadConfiguration();
    }
    
    public static AppConfig getInstance() {
        if (instance == null) {
            instance = new AppConfig();
        }
        return instance;
    }
    
    private void loadConfiguration() {
        // 1. Load defaults from classpath
        try (InputStream is = getClass().getResourceAsStream("/application.properties")) {
            if (is != null) {
                props.load(is);
                log.info("Loaded default configuration");
            }
        } catch (IOException e) {
            log.warn("Could not load default config: {}", e.getMessage());
        }
        
        // 2. Load user config if exists
        File userConfig = new File("config/user.properties");
        if (userConfig.exists()) {
            try (FileInputStream fis = new FileInputStream(userConfig)) {
                Properties userProps = new Properties();
                userProps.load(fis);
                props.putAll(userProps);
                log.info("Loaded user configuration from {}", userConfig);
            } catch (IOException e) {
                log.error("Error loading user config", e);
            }
        }
        
        // 3. Apply environment variables
        System.getenv().forEach((key, value) -> {
            if (key.startsWith("MATSIM_")) {
                String propKey = key.substring(7).toLowerCase().replace('_', '.');
                props.setProperty(propKey, value);
            }
        });
    }
    
    /**
     * Parse command line arguments and validate required parameters
     */
    public void parseArgs(String[] args) {
        if (args.length == 0) {
            printUsageAndExit();
        }
        
        for (int i = 0; i < args.length; i++) {
            String arg = args[i];
            
            if (arg.startsWith("--")) {
                String key = arg.substring(2);
                String value = i + 1 < args.length ? args[++i] : "true";
                
                if (value.startsWith("--")) {
                    value = "true";
                    i--;
                }
                
                cliOverrides.put(key, value);
                log.debug("CLI override: {} = {}", key, value);
            } else if (arg.equals("-h") || arg.equals("--help")) {
                printHelp();
                System.exit(0);
            }
        }
        
        validateRequiredParameters();
    }
    
    private void validateRequiredParameters() {
        List<String> missing = new ArrayList<>();
        
        // Check required parameters
        if (getInt("simulation.population.size") <= 0) {
            missing.add("simulation.population.size");
        }
        if (getInt("simulation.iterations") <= 0) {
            missing.add("simulation.iterations");
        }
        if (getString("simulation.output.dir").isEmpty()) {
            missing.add("simulation.output.dir");
        }
        
        if (!missing.isEmpty()) {
            log.error("Missing required parameters: {}", missing);
            System.err.println("\nERROR: Missing required parameters: " + missing);
            System.err.println("Please provide these parameters via:");
            System.err.println("  1. Command line: --population 10000 --iterations 100");
            System.err.println("  2. Config file: config/user.properties");
            System.err.println("  3. Environment: MATSIM_SIMULATION_POPULATION_SIZE=10000");
            printUsageAndExit();
        }
    }
    
    private void printUsageAndExit() {
        System.err.println("\nUsage: java -jar matsim-lagos.jar [options]");
        System.err.println("\nRequired parameters:");
        System.err.println("  --population <size>    Number of agents (default: 10000)");
        System.err.println("  --iterations <count>   Simulation iterations (default: 100)");
        System.err.println("\nOptional parameters:");
        System.err.println("  --output <dir>         Output directory (default: output)");
        System.err.println("  --config <file>        Custom config file");
        System.err.println("  --enable-okada         Enable Okada motorcycles");
        System.err.println("  --enable-weather       Enable weather impacts");
        System.err.println("  --threads <count>      Number of threads (default: 4)");
        System.err.println("  --mode <type>          Simulation mode (FULL|QUICK|TEST)");
        System.err.println("\nExamples:");
        System.err.println("  java -jar matsim-lagos.jar --population 5000 --iterations 50");
        System.err.println("  java -jar matsim-lagos.jar --config myconfig.properties");
        System.exit(1);
    }
    
    private void printHelp() {
        System.out.println("MATSim Lagos Traffic Simulation");
        System.out.println("================================");
        printUsageAndExit();
    }
    
    // Getter methods with defaults
    public String getString(String key) {
        return getString(key, "");
    }
    
    public String getString(String key, String defaultValue) {
        // Priority: CLI > Environment > Config > Default
        if (cliOverrides.containsKey(key)) {
            return cliOverrides.get(key);
        }
        return props.getProperty(key, defaultValue);
    }
    
    public int getInt(String key) {
        return getInt(key, 0);
    }
    
    public int getInt(String key, int defaultValue) {
        String value = getString(key, String.valueOf(defaultValue));
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            log.warn("Invalid integer for {}: {}, using default: {}", key, value, defaultValue);
            return defaultValue;
        }
    }
    
    public double getDouble(String key) {
        return getDouble(key, 0.0);
    }
    
    public double getDouble(String key, double defaultValue) {
        String value = getString(key, String.valueOf(defaultValue));
        try {
            return Double.parseDouble(value);
        } catch (NumberFormatException e) {
            log.warn("Invalid double for {}: {}, using default: {}", key, value, defaultValue);
            return defaultValue;
        }
    }
    
    public boolean getBoolean(String key) {
        return getBoolean(key, false);
    }
    
    public boolean getBoolean(String key, boolean defaultValue) {
        String value = getString(key, String.valueOf(defaultValue));
        return Boolean.parseBoolean(value);
    }
    
    public void saveUserConfig() {
        File configDir = new File("config");
        if (!configDir.exists()) {
            configDir.mkdirs();
        }
        
        try (FileOutputStream fos = new FileOutputStream("config/user.properties")) {
            props.store(fos, "MATSim Lagos User Configuration");
            log.info("Saved user configuration");
        } catch (IOException e) {
            log.error("Error saving config", e);
        }
    }
    
    // Convenience methods for common parameters
    public int getPopulationSize() {
        return getInt("simulation.population.size", 10000);
    }
    
    public int getIterations() {
        return getInt("simulation.iterations", 100);
    }
    
    public String getOutputDir() {
        return getString("simulation.output.dir", "output");
    }
    
    public boolean isOkadaEnabled() {
        return getBoolean("lagos.enable.okada", false);
    }
    
    public boolean isWeatherEnabled() {
        return getBoolean("lagos.enable.weather", false);
    }
    
    public int getThreadCount() {
        return getInt("performance.threads", Runtime.getRuntime().availableProcessors());
    }
}