package com.emmanuel.matsim;

import com.emmanuel.matsim.config.AppConfig;
import com.emmanuel.matsim.runner.SimulationRunner;

/**
 * Main entry point for MATSim Lagos
 * Usage: java -jar matsim-lagos.jar --population 10000 --iterations 100 [options]
 */
public class Main {
    public static void main(String[] args) {
        try {
            // Load and validate configuration
            AppConfig config = AppConfig.getInstance();
            config.parseArgs(args);
            
            // Run simulation
            SimulationRunner runner = new SimulationRunner(config);
            runner.run();
            
            System.exit(0);
        } catch (Exception e) {
            System.err.println("ERROR: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }
}