package com.emmanuel.matsim.weather;

import org.matsim.api.core.v01.network.Link;
import org.matsim.api.core.v01.network.Network;
import org.matsim.core.mobsim.qsim.qnetsimengine.QVehicle;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.time.LocalDate;
import java.time.Month;
import java.util.*;

/**
 * Weather Impact Model for Lagos Traffic Simulation
 * 
 * Lagos Weather Patterns:
 * - Dry Season: November to March
 * - Rainy Season: April to October
 * - Peak Rainfall: June and September
 * - Average rainfall: 1,693mm annually
 * - Flooding prone areas: Lekki, VI, Apapa, Oshodi
 */
public class WeatherImpactModel {
    private static final Logger log = LogManager.getLogger(WeatherImpactModel.class);
    
    // Weather conditions
    public enum WeatherCondition {
        CLEAR("Clear", 1.0, 0.0),
        LIGHT_RAIN("Light Rain", 0.85, 0.05),
        MODERATE_RAIN("Moderate Rain", 0.70, 0.10),
        HEAVY_RAIN("Heavy Rain", 0.50, 0.20),
        THUNDERSTORM("Thunderstorm", 0.35, 0.30),
        FLOODING("Flooding", 0.10, 0.50);
        
        public final String description;
        public final double speedFactor;
        public final double accidentProbability;
        
        WeatherCondition(String desc, double speed, double accident) {
            this.description = desc;
            this.speedFactor = speed;
            this.accidentProbability = accident;
        }
    }
    
    // Lagos flood-prone areas
    private static final Map<String, Double> FLOOD_PRONE_AREAS = new HashMap<>();
    static {
        FLOOD_PRONE_AREAS.put("Lekki", 0.8);
        FLOOD_PRONE_AREAS.put("Victoria Island", 0.7);
        FLOOD_PRONE_AREAS.put("Ikoyi", 0.6);
        FLOOD_PRONE_AREAS.put("Apapa", 0.75);
        FLOOD_PRONE_AREAS.put("Oshodi", 0.65);
        FLOOD_PRONE_AREAS.put("Marina", 0.7);
        FLOOD_PRONE_AREAS.put("Surulere", 0.5);
        FLOOD_PRONE_AREAS.put("Ikeja", 0.4);
        FLOOD_PRONE_AREAS.put("Mushin", 0.6);
        FLOOD_PRONE_AREAS.put("Agege", 0.55);
    }
    
    // Monthly rainfall probability for Lagos
    private static final Map<Month, RainfallPattern> MONTHLY_PATTERNS = new HashMap<>();
    static {
        MONTHLY_PATTERNS.put(Month.JANUARY, new RainfallPattern(0.05, 28, 15));
        MONTHLY_PATTERNS.put(Month.FEBRUARY, new RainfallPattern(0.08, 46, 20));
        MONTHLY_PATTERNS.put(Month.MARCH, new RainfallPattern(0.15, 82, 25));
        MONTHLY_PATTERNS.put(Month.APRIL, new RainfallPattern(0.35, 146, 30));
        MONTHLY_PATTERNS.put(Month.MAY, new RainfallPattern(0.45, 202, 35));
        MONTHLY_PATTERNS.put(Month.JUNE, new RainfallPattern(0.60, 315, 40)); // Peak
        MONTHLY_PATTERNS.put(Month.JULY, new RainfallPattern(0.50, 243, 35));
        MONTHLY_PATTERNS.put(Month.AUGUST, new RainfallPattern(0.40, 142, 30));
        MONTHLY_PATTERNS.put(Month.SEPTEMBER, new RainfallPattern(0.55, 256, 38)); // Secondary peak
        MONTHLY_PATTERNS.put(Month.OCTOBER, new RainfallPattern(0.35, 125, 28));
        MONTHLY_PATTERNS.put(Month.NOVEMBER, new RainfallPattern(0.10, 40, 20));
        MONTHLY_PATTERNS.put(Month.DECEMBER, new RainfallPattern(0.05, 25, 15));
    }
    
    private WeatherCondition currentCondition = WeatherCondition.CLEAR;
    private LocalDate simulationDate;
    private Random random = new Random();
    private double hourOfDay = 6.0; // Start at 6 AM
    
    // Weather impact statistics
    private int totalRainyHours = 0;
    private int totalFloodEvents = 0;
    private Map<String, Integer> areaFloodCounts = new HashMap<>();
    private List<WeatherEvent> weatherHistory = new ArrayList<>();
    
    public WeatherImpactModel(LocalDate date) {
        this.simulationDate = date != null ? date : LocalDate.now();
        generateInitialWeather();
    }
    
    /**
     * Generate initial weather based on date and season
     */
    private void generateInitialWeather() {
        Month month = simulationDate.getMonth();
        RainfallPattern pattern = MONTHLY_PATTERNS.get(month);
        
        double rand = random.nextDouble();
        if (rand < pattern.rainProbability) {
            // Determine rain intensity
            double intensity = random.nextDouble();
            if (intensity < 0.5) {
                currentCondition = WeatherCondition.LIGHT_RAIN;
            } else if (intensity < 0.8) {
                currentCondition = WeatherCondition.MODERATE_RAIN;
            } else if (intensity < 0.95) {
                currentCondition = WeatherCondition.HEAVY_RAIN;
            } else {
                currentCondition = WeatherCondition.THUNDERSTORM;
            }
        } else {
            currentCondition = WeatherCondition.CLEAR;
        }
        
        log.info("Initial weather for {}: {}", simulationDate, currentCondition.description);
    }
    
    /**
     * Update weather conditions for current simulation time
     */
    public void updateWeather(double simulationTime) {
        hourOfDay = 6.0 + (simulationTime / 3600.0); // Convert seconds to hours from 6 AM
        
        // Weather changes more frequently during rainy season
        Month month = simulationDate.getMonth();
        RainfallPattern pattern = MONTHLY_PATTERNS.get(month);
        
        // Check for weather change every hour
        if (random.nextDouble() < 0.1 * pattern.rainProbability) {
            WeatherCondition oldCondition = currentCondition;
            
            // Transition probabilities
            if (currentCondition == WeatherCondition.CLEAR) {
                if (random.nextDouble() < pattern.rainProbability) {
                    transitionToRain(pattern);
                }
            } else {
                // Rain can intensify, reduce, or stop
                double transition = random.nextDouble();
                if (transition < 0.3) {
                    // Intensify
                    intensifyRain();
                } else if (transition < 0.6) {
                    // Reduce
                    reduceRain();
                } else if (transition < 0.8) {
                    // Stop
                    currentCondition = WeatherCondition.CLEAR;
                }
            }
            
            if (oldCondition != currentCondition) {
                log.info("Weather changed at {:.1f}:00 from {} to {}", 
                    hourOfDay, oldCondition.description, currentCondition.description);
                
                weatherHistory.add(new WeatherEvent(
                    simulationTime, currentCondition, hourOfDay));
            }
        }
        
        // Check for flooding in heavy rain
        if (currentCondition == WeatherCondition.HEAVY_RAIN || 
            currentCondition == WeatherCondition.THUNDERSTORM) {
            checkForFlooding();
        }
        
        // Track statistics
        if (currentCondition != WeatherCondition.CLEAR) {
            totalRainyHours++;
        }
    }
    
    /**
     * Apply weather impact to link travel time
     */
    public double applyWeatherImpact(Link link, double baseTravelTime) {
        double weatherFactor = currentCondition.speedFactor;
        
        // Additional impact for specific road types
        String roadType = (String) link.getAttributes().getAttribute("type");
        if (roadType != null) {
            if (roadType.contains("highway") || roadType.contains("expressway")) {
                // Highways more affected by rain (hydroplaning)
                weatherFactor *= 0.9;
            } else if (roadType.contains("residential") || roadType.contains("tertiary")) {
                // Smaller roads flood more easily
                if (currentCondition == WeatherCondition.HEAVY_RAIN || 
                    currentCondition == WeatherCondition.FLOODING) {
                    weatherFactor *= 0.7;
                }
            }
        }
        
        // Check if link is in flood-prone area
        String area = getAreaName(link);
        if (area != null && FLOOD_PRONE_AREAS.containsKey(area)) {
            double floodRisk = FLOOD_PRONE_AREAS.get(area);
            if (currentCondition == WeatherCondition.FLOODING) {
                weatherFactor *= (1.0 - floodRisk * 0.5); // Up to 50% additional slowdown
            }
        }
        
        return baseTravelTime / weatherFactor;
    }
    
    /**
     * Check for accident probability due to weather
     */
    public boolean checkForAccident(Link link, String vehicleType) {
        double accidentProb = currentCondition.accidentProbability;
        
        // Adjust for vehicle type
        switch (vehicleType) {
            case "okada":
                accidentProb *= 2.0; // Motorcycles more vulnerable
                break;
            case "danfo":
                accidentProb *= 1.2; // Old buses, poor maintenance
                break;
            case "brt":
                accidentProb *= 0.5; // Better maintained, professional drivers
                break;
            case "car":
                accidentProb *= 1.0; // Base rate
                break;
        }
        
        // Time of day factor (visibility)
        if (hourOfDay < 6 || hourOfDay > 19) {
            accidentProb *= 1.5; // Night time
        }
        
        return random.nextDouble() < accidentProb;
    }
    
    /**
     * Get mode-specific weather impact
     */
    public ModeWeatherImpact getModeImpact(String mode) {
        switch (mode) {
            case "walk":
                return new ModeWeatherImpact(
                    currentCondition.speedFactor * 0.7, // Walking very slow in rain
                    currentCondition == WeatherCondition.FLOODING ? 0.0 : 1.0 // Can't walk in floods
                );
            case "okada":
                return new ModeWeatherImpact(
                    currentCondition.speedFactor * 0.6, // Motorcycles dangerous in rain
                    currentCondition == WeatherCondition.THUNDERSTORM ? 0.2 : 0.8
                );
            case "danfo":
            case "bus":
                return new ModeWeatherImpact(
                    currentCondition.speedFactor * 0.9,
                    1.0 // Buses still operate
                );
            case "brt":
                return new ModeWeatherImpact(
                    currentCondition.speedFactor * 0.95, // Dedicated lanes help
                    1.0
                );
            case "car":
            default:
                return new ModeWeatherImpact(
                    currentCondition.speedFactor,
                    currentCondition == WeatherCondition.FLOODING ? 0.3 : 1.0
                );
        }
    }
    
    /**
     * Transition to rainy weather
     */
    private void transitionToRain(RainfallPattern pattern) {
        double intensity = random.nextDouble() * pattern.maxIntensity;
        
        if (intensity < 20) {
            currentCondition = WeatherCondition.LIGHT_RAIN;
        } else if (intensity < 30) {
            currentCondition = WeatherCondition.MODERATE_RAIN;
        } else if (intensity < 38) {
            currentCondition = WeatherCondition.HEAVY_RAIN;
        } else {
            currentCondition = WeatherCondition.THUNDERSTORM;
        }
    }
    
    /**
     * Intensify current rain
     */
    private void intensifyRain() {
        switch (currentCondition) {
            case LIGHT_RAIN:
                currentCondition = WeatherCondition.MODERATE_RAIN;
                break;
            case MODERATE_RAIN:
                currentCondition = WeatherCondition.HEAVY_RAIN;
                break;
            case HEAVY_RAIN:
                currentCondition = random.nextDouble() < 0.3 ? 
                    WeatherCondition.THUNDERSTORM : WeatherCondition.HEAVY_RAIN;
                break;
        }
    }
    
    /**
     * Reduce rain intensity
     */
    private void reduceRain() {
        switch (currentCondition) {
            case THUNDERSTORM:
                currentCondition = WeatherCondition.HEAVY_RAIN;
                break;
            case HEAVY_RAIN:
                currentCondition = WeatherCondition.MODERATE_RAIN;
                break;
            case MODERATE_RAIN:
                currentCondition = WeatherCondition.LIGHT_RAIN;
                break;
            case LIGHT_RAIN:
                currentCondition = WeatherCondition.CLEAR;
                break;
        }
    }
    
    /**
     * Check for flooding conditions
     */
    private void checkForFlooding() {
        // Flooding probability increases with sustained heavy rain
        if (totalRainyHours > 3 && random.nextDouble() < 0.2) {
            currentCondition = WeatherCondition.FLOODING;
            totalFloodEvents++;
            
            // Affect flood-prone areas
            for (String area : FLOOD_PRONE_AREAS.keySet()) {
                if (random.nextDouble() < FLOOD_PRONE_AREAS.get(area)) {
                    areaFloodCounts.merge(area, 1, Integer::sum);
                    log.warn("FLOODING in {} area!", area);
                }
            }
        }
    }
    
    /**
     * Get area name from link
     */
    private String getAreaName(Link link) {
        // This would normally use actual geographic data
        // For now, return a random flood-prone area for demonstration
        if (link.getAttributes().getAttribute("area") != null) {
            return (String) link.getAttributes().getAttribute("area");
        }
        return null;
    }
    
    /**
     * Get current weather condition
     */
    public WeatherCondition getCurrentCondition() {
        return currentCondition;
    }
    
    /**
     * Print weather statistics
     */
    public void printStatistics() {
        log.info("=== Weather Impact Statistics ===");
        log.info("Simulation Date: {}", simulationDate);
        log.info("Total Rainy Hours: {}", totalRainyHours);
        log.info("Total Flood Events: {}", totalFloodEvents);
        
        if (!areaFloodCounts.isEmpty()) {
            log.info("Flooding by Area:");
            areaFloodCounts.forEach((area, count) -> 
                log.info("  {}: {} times", area, count));
        }
        
        // Weather distribution
        Map<WeatherCondition, Long> distribution = new HashMap<>();
        for (WeatherEvent event : weatherHistory) {
            distribution.merge(event.condition, 1L, Long::sum);
        }
        
        log.info("Weather Distribution:");
        distribution.forEach((condition, count) -> 
            log.info("  {}: {} hours", condition.description, count));
    }
    
    // Helper classes
    public static class RainfallPattern {
        public final double rainProbability;
        public final double avgRainfall; // mm
        public final double maxIntensity; // mm/hour
        
        public RainfallPattern(double prob, double avg, double max) {
            this.rainProbability = prob;
            this.avgRainfall = avg;
            this.maxIntensity = max;
        }
    }
    
    public static class ModeWeatherImpact {
        public final double speedFactor;
        public final double availability; // 0.0 to 1.0
        
        public ModeWeatherImpact(double speed, double avail) {
            this.speedFactor = speed;
            this.availability = avail;
        }
    }
    
    public static class WeatherEvent {
        public final double time;
        public final WeatherCondition condition;
        public final double hour;
        
        public WeatherEvent(double time, WeatherCondition condition, double hour) {
            this.time = time;
            this.condition = condition;
            this.hour = hour;
        }
    }
}