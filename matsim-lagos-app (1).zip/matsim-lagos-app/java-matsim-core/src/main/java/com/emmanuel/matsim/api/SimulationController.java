package com.emmanuel.matsim.api;

import com.emmanuel.matsim.runner.SimulationRunner;
import com.emmanuel.matsim.utils.ResultsAnalyzer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.*;
import java.util.concurrent.*;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * REST API Controller for MATSim Lagos Simulation
 * Provides endpoints for simulation control and monitoring
 */
public class SimulationController {
    private static final Logger log = LogManager.getLogger(SimulationController.class);
    
    private SimulationRunner currentSimulation;
    private ExecutorService executorService = Executors.newSingleThreadExecutor();
    private Future<?> simulationFuture;
    private SimulationStatus status = new SimulationStatus();
    private List<SimulationListener> listeners = new CopyOnWriteArrayList<>();
    
    // Simulation state
    private volatile boolean isRunning = false;
    private volatile boolean isPaused = false;
    private int currentIteration = 0;
    private int totalIterations = 100;
    
    // Lagos-specific metrics
    private Map<String, Double> lagosMetrics = new ConcurrentHashMap<>();
    
    public SimulationController() {
        initializeLagosMetrics();
    }
    
    private void initializeLagosMetrics() {
        lagosMetrics.put("congestion_level", 0.5);
        lagosMetrics.put("danfo_utilization", 0.0);
        lagosMetrics.put("brt_utilization", 0.0);
        lagosMetrics.put("okada_activity", 0.0);
        lagosMetrics.put("rainfall_impact", 0.0);
        lagosMetrics.put("market_day_factor", 1.0);
        lagosMetrics.put("fuel_availability", 1.0);
        lagosMetrics.put("accident_count", 0.0);
        lagosMetrics.put("average_speed_kmh", 35.0);
        lagosMetrics.put("third_mainland_flow", 0.0);
    }
    
    /**
     * Start a new simulation
     */
    public SimulationResponse startSimulation(SimulationRequest request) {
        if (isRunning) {
            return new SimulationResponse(false, "Simulation already running", status);
        }
        
        isRunning = true;
        isPaused = false;
        currentIteration = 0;
        totalIterations = request.getIterations() > 0 ? request.getIterations() : 100;
        
        status.setStatus("INITIALIZING");
        status.setStartTime(System.currentTimeMillis());
        
        simulationFuture = executorService.submit(() -> {
            try {
                currentSimulation = new SimulationRunner();
                
                // Configure Lagos-specific parameters
                configureLagosSimulation(request);
                
                // Run simulation with callbacks
                for (int i = 0; i < totalIterations && isRunning; i++) {
                    while (isPaused && isRunning) {
                        Thread.sleep(100);
                    }
                    
                    currentIteration = i;
                    status.setCurrentIteration(i);
                    status.setProgress((i * 100.0) / totalIterations);
                    status.setStatus("RUNNING");
                    
                    // Simulate iteration
                    simulateIteration(i);
                    
                    // Update Lagos metrics
                    updateLagosMetrics(i);
                    
                    // Notify listeners
                    notifyListeners();
                    
                    Thread.sleep(request.getDelayMs()); // Configurable delay
                }
                
                status.setStatus("COMPLETED");
                status.setEndTime(System.currentTimeMillis());
                
            } catch (Exception e) {
                log.error("Simulation failed", e);
                status.setStatus("ERROR");
                status.setErrorMessage(e.getMessage());
            } finally {
                isRunning = false;
            }
        });
        
        return new SimulationResponse(true, "Simulation started", status);
    }
    
    /**
     * Pause the running simulation
     */
    public SimulationResponse pauseSimulation() {
        if (!isRunning) {
            return new SimulationResponse(false, "No simulation running", status);
        }
        
        isPaused = true;
        status.setStatus("PAUSED");
        return new SimulationResponse(true, "Simulation paused", status);
    }
    
    /**
     * Resume paused simulation
     */
    public SimulationResponse resumeSimulation() {
        if (!isRunning || !isPaused) {
            return new SimulationResponse(false, "No paused simulation to resume", status);
        }
        
        isPaused = false;
        status.setStatus("RUNNING");
        return new SimulationResponse(true, "Simulation resumed", status);
    }
    
    /**
     * Stop the simulation
     */
    public SimulationResponse stopSimulation() {
        if (!isRunning) {
            return new SimulationResponse(false, "No simulation running", status);
        }
        
        isRunning = false;
        if (simulationFuture != null) {
            simulationFuture.cancel(true);
        }
        
        status.setStatus("STOPPED");
        status.setEndTime(System.currentTimeMillis());
        return new SimulationResponse(true, "Simulation stopped", status);
    }
    
    /**
     * Get current simulation status
     */
    public SimulationStatus getStatus() {
        status.setLagosMetrics(new HashMap<>(lagosMetrics));
        return status;
    }
    
    /**
     * Get Lagos-specific metrics
     */
    public Map<String, Object> getLagosTrafficData() {
        Map<String, Object> data = new HashMap<>();
        
        // Traffic zones with current conditions
        data.put("zones", Arrays.asList(
            createZoneData("Island", "Victoria Island, Ikoyi, Lekki", 
                           lagosMetrics.get("congestion_level") * 1.2),
            createZoneData("Mainland", "Yaba, Surulere, Mushin", 
                           lagosMetrics.get("congestion_level")),
            createZoneData("Ikeja", "Ikeja, Ogba, Agege", 
                           lagosMetrics.get("congestion_level") * 1.1),
            createZoneData("Apapa", "Apapa, Tin Can, Wharf", 
                           lagosMetrics.get("congestion_level") * 1.3)
        ));
        
        // Major routes status
        data.put("major_routes", Arrays.asList(
            createRouteData("Third Mainland Bridge", 
                          lagosMetrics.get("third_mainland_flow"), 11.8),
            createRouteData("Lekki-Epe Expressway", 
                          lagosMetrics.get("congestion_level") * 0.9, 49.4),
            createRouteData("Lagos-Ibadan Expressway", 
                          lagosMetrics.get("congestion_level") * 0.85, 45.0),
            createRouteData("Apapa-Oshodi Expressway", 
                          lagosMetrics.get("congestion_level") * 1.4, 24.7)
        ));
        
        // Transport modes
        data.put("transport_modes", Arrays.asList(
            createModeData("BRT", lagosMetrics.get("brt_utilization"), 220000),
            createModeData("Danfo", lagosMetrics.get("danfo_utilization"), 450000),
            createModeData("Okada", lagosMetrics.get("okada_activity"), 180000),
            createModeData("Keke", lagosMetrics.get("congestion_level") * 0.3, 75000),
            createModeData("Private Cars", lagosMetrics.get("congestion_level"), 1200000)
        ));
        
        // Current conditions
        data.put("current_conditions", Map.of(
            "time_of_day", getTimeOfDay(currentIteration),
            "weather", lagosMetrics.get("rainfall_impact") > 0 ? "Rainy" : "Clear",
            "fuel_status", getFuelStatus(lagosMetrics.get("fuel_availability")),
            "incidents", (int) Math.round(lagosMetrics.get("accident_count")),
            "average_speed", lagosMetrics.get("average_speed_kmh"),
            "market_day", lagosMetrics.get("market_day_factor") > 1.2
        ));
        
        return data;
    }
    
    /**
     * Configure Lagos-specific simulation parameters
     */
    private void configureLagosSimulation(SimulationRequest request) {
        // Lagos-specific factors
        if (request.getParameters() != null) {
            // Weather impact (rainy season: April-July, Sept-Oct)
            Boolean rainyDay = (Boolean) request.getParameters().get("rainy_day");
            if (rainyDay != null && rainyDay) {
                lagosMetrics.put("rainfall_impact", 0.3); // 30% speed reduction
            }
            
            // Market day impact (typically Wednesdays and Saturdays)
            Boolean marketDay = (Boolean) request.getParameters().get("market_day");
            if (marketDay != null && marketDay) {
                lagosMetrics.put("market_day_factor", 1.5); // 50% more trips
            }
            
            // Fuel scarcity scenario
            Boolean fuelScarcity = (Boolean) request.getParameters().get("fuel_scarcity");
            if (fuelScarcity != null && fuelScarcity) {
                lagosMetrics.put("fuel_availability", 0.4); // 60% reduction
            }
            
            // Enable Okada mode
            Boolean enableOkada = (Boolean) request.getParameters().get("enable_okada");
            if (enableOkada != null && enableOkada) {
                lagosMetrics.put("okada_activity", 0.25); // 25% mode share
            }
        }
    }
    
    /**
     * Simulate one iteration with Lagos patterns
     */
    private void simulateIteration(int iteration) {
        // Time of day effects (6 AM start, 15 min increments)
        double hour = 6.0 + (iteration * 0.25);
        
        // Morning peak (6:30 AM - 10:00 AM)
        if (hour >= 6.5 && hour <= 10.0) {
            lagosMetrics.put("congestion_level", 0.75 + Math.random() * 0.2);
            lagosMetrics.put("danfo_utilization", 0.85 + Math.random() * 0.1);
            lagosMetrics.put("brt_utilization", 0.90 + Math.random() * 0.08);
        }
        // Midday (10:00 AM - 4:00 PM)
        else if (hour > 10.0 && hour <= 16.0) {
            lagosMetrics.put("congestion_level", 0.5 + Math.random() * 0.2);
            lagosMetrics.put("danfo_utilization", 0.6 + Math.random() * 0.15);
            lagosMetrics.put("brt_utilization", 0.5 + Math.random() * 0.2);
        }
        // Evening peak (4:00 PM - 9:00 PM)
        else if (hour > 16.0 && hour <= 21.0) {
            lagosMetrics.put("congestion_level", 0.85 + Math.random() * 0.13);
            lagosMetrics.put("danfo_utilization", 0.9 + Math.random() * 0.08);
            lagosMetrics.put("brt_utilization", 0.85 + Math.random() * 0.12);
        }
        // Night (9:00 PM - 6:00 AM)
        else {
            lagosMetrics.put("congestion_level", 0.2 + Math.random() * 0.15);
            lagosMetrics.put("danfo_utilization", 0.3 + Math.random() * 0.2);
            lagosMetrics.put("brt_utilization", 0.2 + Math.random() * 0.1);
        }
        
        // Third Mainland Bridge specific (busiest bridge)
        lagosMetrics.put("third_mainland_flow", 
            lagosMetrics.get("congestion_level") * 1.2 * (1 - lagosMetrics.get("rainfall_impact")));
        
        // Calculate average speed based on congestion
        double baseSpeed = 60.0; // km/h
        double congestionImpact = lagosMetrics.get("congestion_level");
        double rainImpact = lagosMetrics.get("rainfall_impact");
        lagosMetrics.put("average_speed_kmh", 
            baseSpeed * (1 - congestionImpact * 0.6) * (1 - rainImpact));
        
        // Random incidents
        if (Math.random() < 0.05) { // 5% chance per iteration
            lagosMetrics.put("accident_count", lagosMetrics.get("accident_count") + 1);
        }
    }
    
    /**
     * Update Lagos-specific metrics
     */
    private void updateLagosMetrics(int iteration) {
        // Okada activity increases in congestion
        if (lagosMetrics.get("okada_activity") > 0) {
            double congestion = lagosMetrics.get("congestion_level");
            lagosMetrics.put("okada_activity", 
                Math.min(0.4, 0.25 * (1 + congestion * 0.5)));
        }
        
        // Fuel availability affects private car usage
        double fuelAvail = lagosMetrics.get("fuel_availability");
        if (fuelAvail < 1.0) {
            // Reduce car trips, increase public transport
            lagosMetrics.put("danfo_utilization", 
                Math.min(1.0, lagosMetrics.get("danfo_utilization") * (2 - fuelAvail)));
            lagosMetrics.put("brt_utilization", 
                Math.min(1.0, lagosMetrics.get("brt_utilization") * (2 - fuelAvail)));
        }
    }
    
    /**
     * Add simulation listener for real-time updates
     */
    public void addListener(SimulationListener listener) {
        listeners.add(listener);
    }
    
    public void removeListener(SimulationListener listener) {
        listeners.remove(listener);
    }
    
    private void notifyListeners() {
        SimulationEvent event = new SimulationEvent(
            currentIteration, 
            status.getProgress(), 
            new HashMap<>(lagosMetrics)
        );
        
        for (SimulationListener listener : listeners) {
            try {
                listener.onSimulationUpdate(event);
            } catch (Exception e) {
                log.error("Error notifying listener", e);
            }
        }
    }
    
    // Helper methods
    private Map<String, Object> createZoneData(String name, String areas, double congestion) {
        return Map.of(
            "name", name,
            "areas", areas,
            "congestion", Math.min(1.0, Math.max(0.0, congestion)),
            "status", congestion > 0.8 ? "SEVERE" : congestion > 0.5 ? "MODERATE" : "LIGHT"
        );
    }
    
    private Map<String, Object> createRouteData(String name, double flow, double length) {
        return Map.of(
            "name", name,
            "flow", Math.min(1.0, Math.max(0.0, flow)),
            "length_km", length,
            "travel_time_min", length / lagosMetrics.get("average_speed_kmh") * 60
        );
    }
    
    private Map<String, Object> createModeData(String mode, double utilization, int dailyTrips) {
        return Map.of(
            "mode", mode,
            "utilization", Math.min(1.0, Math.max(0.0, utilization)),
            "daily_trips", dailyTrips,
            "current_trips", (int) (dailyTrips * utilization / 24)
        );
    }
    
    private String getTimeOfDay(int iteration) {
        double hour = 6.0 + (iteration * 0.25);
        int h = (int) hour;
        int m = (int) ((hour - h) * 60);
        return String.format("%02d:%02d", h % 24, m);
    }
    
    private String getFuelStatus(double availability) {
        if (availability >= 0.9) return "Normal";
        if (availability >= 0.6) return "Limited";
        if (availability >= 0.3) return "Scarcity";
        return "Severe Scarcity";
    }
    
    // Inner classes for API
    public static class SimulationRequest {
        private int populationSize = 10000;
        private int iterations = 100;
        private int delayMs = 500;
        private Map<String, Object> parameters = new HashMap<>();
        
        // Getters and setters
        public int getPopulationSize() { return populationSize; }
        public void setPopulationSize(int size) { this.populationSize = size; }
        public int getIterations() { return iterations; }
        public void setIterations(int iter) { this.iterations = iter; }
        public int getDelayMs() { return delayMs; }
        public void setDelayMs(int delay) { this.delayMs = delay; }
        public Map<String, Object> getParameters() { return parameters; }
        public void setParameters(Map<String, Object> params) { this.parameters = params; }
    }
    
    public static class SimulationResponse {
        private boolean success;
        private String message;
        private SimulationStatus status;
        
        public SimulationResponse(boolean success, String message, SimulationStatus status) {
            this.success = success;
            this.message = message;
            this.status = status;
        }
        
        // Getters
        public boolean isSuccess() { return success; }
        public String getMessage() { return message; }
        public SimulationStatus getStatus() { return status; }
    }
    
    public static class SimulationStatus {
        private String status = "IDLE";
        private int currentIteration = 0;
        private double progress = 0.0;
        private long startTime = 0;
        private long endTime = 0;
        private String errorMessage = null;
        private Map<String, Double> lagosMetrics = new HashMap<>();
        
        // Getters and setters
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
        public int getCurrentIteration() { return currentIteration; }
        public void setCurrentIteration(int iter) { this.currentIteration = iter; }
        public double getProgress() { return progress; }
        public void setProgress(double prog) { this.progress = prog; }
        public long getStartTime() { return startTime; }
        public void setStartTime(long time) { this.startTime = time; }
        public long getEndTime() { return endTime; }
        public void setEndTime(long time) { this.endTime = time; }
        public String getErrorMessage() { return errorMessage; }
        public void setErrorMessage(String msg) { this.errorMessage = msg; }
        public Map<String, Double> getLagosMetrics() { return lagosMetrics; }
        public void setLagosMetrics(Map<String, Double> metrics) { this.lagosMetrics = metrics; }
    }
    
    public interface SimulationListener {
        void onSimulationUpdate(SimulationEvent event);
    }
    
    public static class SimulationEvent {
        private final int iteration;
        private final double progress;
        private final Map<String, Double> metrics;
        
        public SimulationEvent(int iteration, double progress, Map<String, Double> metrics) {
            this.iteration = iteration;
            this.progress = progress;
            this.metrics = metrics;
        }
        
        public int getIteration() { return iteration; }
        public double getProgress() { return progress; }
        public Map<String, Double> getMetrics() { return metrics; }
    }
}