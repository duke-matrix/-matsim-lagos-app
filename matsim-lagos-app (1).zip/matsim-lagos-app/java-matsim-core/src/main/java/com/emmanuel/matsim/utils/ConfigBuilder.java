package com.emmanuel.matsim.utils;

import org.matsim.core.config.Config;
import org.matsim.core.config.ConfigUtils;
import org.matsim.core.config.groups.PlanCalcScoreConfigGroup;
import org.matsim.core.config.groups.StrategyConfigGroup;
import org.matsim.api.core.v01.TransportMode;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ConfigBuilder {
    private static final Logger log = LogManager.getLogger(ConfigBuilder.class);
    
    public static Config createConfig(String outputDirectory) {
        Config config = ConfigUtils.createConfig();
        
        config.global().setCoordinateSystem("EPSG:32631");
        config.global().setRandomSeed(42);
        
        config.controler().setOutputDirectory(outputDirectory);
        config.controler().setRunId("lagos-simulation");
        
        config.qsim().setStartTime(0);
        config.qsim().setEndTime(30 * 3600);
        config.qsim().setFlowCapFactor(0.1);
        config.qsim().setStorageCapFactor(0.3);
        config.qsim().setNumberOfThreads(Runtime.getRuntime().availableProcessors());
        config.qsim().setRemoveStuckVehicles(true);
        config.qsim().setStuckTime(10.0);
        
        config.transit().setUseTransit(true);
        config.transit().setTransitModes("pt");
        
        config.plansCalcRoute().setNetworkModes(java.util.Arrays.asList(
            TransportMode.car, "bus", TransportMode.walk));
        
        config.planCalcScore().setLearningRate(1.0);
        config.planCalcScore().setBrainExpBeta(2.0);
        config.planCalcScore().setPerforming_utils_hr(6.0);
        config.planCalcScore().setMarginalUtilityOfMoney(1.0);
        config.planCalcScore().setUtilityOfLineSwitch(-1.0);
        config.planCalcScore().setLateArrival_utils_hr(-18.0);
        config.planCalcScore().setEarlyDeparture_utils_hr(-0.0);
        config.planCalcScore().setMarginalUtlOfWaitingPt_utils_hr(-6.0);
        
        log.info("Created base configuration for Lagos simulation");
        return config;
    }
    
    public static PlanCalcScoreConfigGroup.ActivityParams createActivityParams(
            String activityType, double typicalDuration) {
        PlanCalcScoreConfigGroup.ActivityParams params = 
            new PlanCalcScoreConfigGroup.ActivityParams(activityType);
        params.setTypicalDuration(typicalDuration);
        params.setPriority(1.0);
        
        switch (activityType) {
            case "work":
                params.setOpeningTime(6 * 3600);
                params.setClosingTime(22 * 3600);
                params.setLatestStartTime(10 * 3600);
                params.setMinimalDuration(4 * 3600);
                break;
            case "market":
                params.setOpeningTime(5 * 3600);
                params.setClosingTime(21 * 3600);
                params.setMinimalDuration(0.5 * 3600);
                break;
            case "school":
                params.setOpeningTime(7 * 3600);
                params.setClosingTime(18 * 3600);
                params.setMinimalDuration(1 * 3600);
                break;
            case "home":
                params.setMinimalDuration(8 * 3600);
                break;
        }
        
        return params;
    }
    
    public static void addStrategySettings(Config config, String strategyName, double weight) {
        StrategyConfigGroup.StrategySettings settings = new StrategyConfigGroup.StrategySettings();
        settings.setStrategyName(strategyName);
        settings.setWeight(weight);
        
        switch (strategyName) {
            case "ReRoute":
                settings.setDisableAfter(80);
                break;
            case "TimeAllocationMutator":
                settings.setDisableAfter(90);
                break;
            case "ChangeSingleTripMode":
                settings.setDisableAfter(80);
                break;
        }
        
        config.strategy().addStrategySettings(settings);
        log.debug("Added strategy: {} with weight: {}", strategyName, weight);
    }
    
    public static void configureLagosSpecificSettings(Config config) {
        config.vspExperimental().setVspDefaultsCheckingLevel(
            org.matsim.core.config.groups.VspExperimentalConfigGroup.VspDefaultsCheckingLevel.warn);
        
        config.parallelEventHandling().setNumberOfThreads(
            Runtime.getRuntime().availableProcessors());
        config.parallelEventHandling().setEstimatedNumberOfEvents(1000000);
        
        config.global().setNumberOfThreads(
            Runtime.getRuntime().availableProcessors());
        
        log.info("Applied Lagos-specific configuration settings");
    }
    
    public static void addTransitModules(Config config) {
        config.transit().setUseTransit(true);
        config.transit().setTransitModes("pt");
        config.transit().setBoardingAcceptance("checkStopTimes");
        config.transit().setVehiclesFile("transit-vehicles.xml.gz");
        config.transit().setTransitScheduleFile("transit-schedule.xml.gz");
        
        log.info("Transit modules configured");
    }
    
    public static class LagosDefaults {
        public static final double CAR_SPEED_FACTOR = 0.7;
        public static final double BUS_SPEED_FACTOR = 0.5;
        public static final double WALK_SPEED = 4.0 / 3.6;
        public static final double BRT_HEADWAY_SECONDS = 600;
        public static final double DANFO_HEADWAY_SECONDS = 300;
        public static final int DEFAULT_POPULATION_SIZE = 10000;
        public static final int DEFAULT_ITERATIONS = 100;
        public static final double TRAFFIC_CONGESTION_FACTOR = 0.6;
    }
}