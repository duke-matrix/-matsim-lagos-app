package com.emmanuel.matsim.alerts;

import java.util.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * WhatsApp Bot for Lagos Traffic Updates
 * Sends traffic alerts and responds to queries
 */
public class WhatsAppBot {
    
    private static final String TWILIO_ACCOUNT_SID = System.getenv("TWILIO_ACCOUNT_SID");
    private static final String TWILIO_AUTH_TOKEN = System.getenv("TWILIO_AUTH_TOKEN");
    private static final String WHATSAPP_FROM = "whatsapp:+14155238886"; // Twilio Sandbox
    
    private Map<String, UserPreference> userPreferences;
    private Queue<TrafficAlert> alertQueue;
    
    public WhatsAppBot() {
        this.userPreferences = new HashMap<>();
        this.alertQueue = new LinkedList<>();
    }
    
    /**
     * Process incoming WhatsApp message
     */
    public String processMessage(String from, String message) {
        message = message.toLowerCase().trim();
        
        // Greeting
        if (message.contains("hello") || message.contains("hi")) {
            return "Omo Lagos! 🚦 Welcome to Traffic Wahala Bot!\n\n" +
                   "Send these commands:\n" +
                   "📍 'traffic [location]' - Check traffic\n" +
                   "🛣️ 'route [from] to [to]' - Get best route\n" +
                   "🚨 'alerts on/off' - Toggle alerts\n" +
                   "📊 'hotspots' - Current traffic hotspots\n" +
                   "⏰ 'predict [time] [location]' - Future traffic\n\n" +
                   "Example: 'traffic lekki'";
        }
        
        // Check traffic for location
        if (message.startsWith("traffic ")) {
            String location = message.substring(8);
            return getTrafficUpdate(location);
        }
        
        // Route planning
        if (message.contains(" to ")) {
            return getRouteAdvice(message);
        }
        
        // Hotspots
        if (message.equals("hotspots")) {
            return getCurrentHotspots();
        }
        
        // Alerts management
        if (message.startsWith("alerts ")) {
            String action = message.substring(7);
            return manageAlerts(from, action);
        }
        
        // Prediction
        if (message.startsWith("predict ")) {
            return getPrediction(message.substring(8));
        }
        
        // Default response
        return "Oga, I no understand that one o. 🤔\n" +
               "Send 'hi' to see wetin I fit do for you.";
    }
    
    private String getTrafficUpdate(String location) {
        // Simulate traffic check
        Random rand = new Random();
        int congestion = rand.nextInt(10) + 1;
        
        String status;
        String advice;
        String emoji;
        
        if (congestion <= 3) {
            status = "Road dey free well well";
            advice = "You fit move now, no wahala";
            emoji = "🟢";
        } else if (congestion <= 6) {
            status = "Small hold-up dey";
            advice = "E go take like 20-30 mins extra";
            emoji = "🟡";
        } else if (congestion <= 8) {
            status = "Serious go-slow dey o";
            advice = "Find alternative route sharp sharp";
            emoji = "🟠";
        } else {
            status = "Everywhere don lock!";
            advice = "If e no urgent, stay where you dey";
            emoji = "🔴";
        }
        
        return String.format(
            "%s *Traffic Update for %s*\n\n" +
            "Status: %s\n" +
            "Congestion Level: %d/10\n" +
            "Advice: %s\n\n" +
            "Major roads affected:\n" +
            "• %s\n" +
            "• %s\n\n" +
            "⏱️ Updated: %s",
            emoji, 
            capitalize(location),
            status,
            congestion,
            advice,
            getAffectedRoad(location, 1),
            getAffectedRoad(location, 2),
            LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm"))
        );
    }
    
    private String getRouteAdvice(String message) {
        // Parse from and to
        String[] parts = message.split(" to ");
        if (parts.length != 2) {
            return "Format: 'route [from] to [to]'\nExample: 'route lekki to vi'";
        }
        
        String from = parts[0].replace("route ", "").trim();
        String to = parts[1].trim();
        
        return String.format(
            "🗺️ *Route from %s to %s*\n\n" +
            "✅ *Best Route (35 mins):*\n" +
            "1. Take Lekki-Epe Expressway\n" +
            "2. Enter Ozumba Mbadiwe\n" +
            "3. Turn right at Adeola Odeku\n\n" +
            "⚠️ *Avoid:*\n" +
            "• Third Mainland Bridge (45 mins delay)\n" +
            "• Eko Bridge (Accident reported)\n\n" +
            "💡 *Alternative:*\n" +
            "Consider Uber Boat from Lekki Jetty (15 mins)\n\n" +
            "Safe journey! 🚗",
            capitalize(from),
            capitalize(to)
        );
    }
    
    private String getCurrentHotspots() {
        return "🔴 *Current Traffic Hotspots*\n\n" +
               "1. *Oshodi* - Everywhere don cast! (9/10)\n" +
               "   Cause: Trailer breakdown\n\n" +
               "2. *Third Mainland Bridge* - Heavy traffic (8/10)\n" +
               "   Cause: Rush hour wahala\n\n" +
               "3. *Lekki Toll Gate* - Building up (7/10)\n" +
               "   Cause: Friday evening rush\n\n" +
               "4. *Maryland* - Slow movement (6/10)\n" +
               "   Cause: Traffic light palava\n\n" +
               "5. *Apapa* - As usual (8/10)\n" +
               "   Cause: Container trucks\n\n" +
               "💡 Tip: Use inner roads or wait till 8pm";
    }
    
    private String manageAlerts(String userId, String action) {
        if (action.equals("on")) {
            userPreferences.put(userId, new UserPreference(true));
            return "✅ Traffic alerts don dey on!\n\n" +
                   "You go dey receive:\n" +
                   "• Morning traffic summary (6:30 AM)\n" +
                   "• Evening traffic update (4:30 PM)\n" +
                   "• Major incident alerts\n\n" +
                   "Send 'alerts off' to stop am.";
        } else if (action.equals("off")) {
            userPreferences.put(userId, new UserPreference(false));
            return "📴 Traffic alerts don off.\n\n" +
                   "You no go receive automatic updates again.\n" +
                   "Send 'alerts on' to start am back.";
        }
        
        return "Use 'alerts on' or 'alerts off'";
    }
    
    private String getPrediction(String params) {
        // Simple prediction
        return "🔮 *Traffic Prediction*\n\n" +
               "Based on historical data:\n\n" +
               "📈 *Expected Traffic Pattern:*\n" +
               "6:00 AM - Light (3/10)\n" +
               "7:00 AM - Building (5/10)\n" +
               "8:00 AM - Heavy (8/10)\n" +
               "9:00 AM - Peak (9/10)\n" +
               "10:00 AM - Reducing (7/10)\n\n" +
               "⚠️ *Potential Issues:*\n" +
               "• 70% chance of Oshodi gridlock\n" +
               "• 45% chance of Third Mainland delay\n\n" +
               "💡 *Recommendation:*\n" +
               "Leave before 6:30 AM or after 10:00 AM";
    }
    
    /**
     * Send traffic alert to subscribed users
     */
    public void sendAlert(String userId, TrafficAlert alert) {
        UserPreference pref = userPreferences.get(userId);
        if (pref != null && pref.alertsEnabled) {
            String message = formatAlert(alert);
            // In production, this would use Twilio API
            System.out.println("Sending to " + userId + ": " + message);
        }
    }
    
    /**
     * Send morning traffic summary
     */
    public void sendMorningSummary() {
        String summary = "🌅 *Good Morning Lagos!*\n\n" +
                        "Today's Traffic Forecast:\n\n" +
                        "🟢 Clear: Ikoyi, Banana Island\n" +
                        "🟡 Moderate: Lekki, VI\n" +
                        "🔴 Heavy: Oshodi, Maryland, Ikeja\n\n" +
                        "⚠️ Avoid: Third Mainland (Repairs)\n\n" +
                        "Best time to move: Before 6:30 AM\n\n" +
                        "Have a traffic-free day! 🚗";
        
        broadcastToSubscribers(summary);
    }
    
    private String formatAlert(TrafficAlert alert) {
        return String.format(
            "🚨 *Traffic Alert!*\n\n" +
            "%s\n" +
            "Location: %s\n" +
            "Impact: %s\n" +
            "Duration: %s\n\n" +
            "Alternative routes available.",
            alert.description,
            alert.location,
            alert.severity,
            alert.estimatedDuration
        );
    }
    
    private void broadcastToSubscribers(String message) {
        for (Map.Entry<String, UserPreference> entry : userPreferences.entrySet()) {
            if (entry.getValue().alertsEnabled) {
                // Send via Twilio in production
                System.out.println("Broadcasting to " + entry.getKey());
            }
        }
    }
    
    private String getAffectedRoad(String location, int index) {
        Map<String, List<String>> roads = new HashMap<>();
        roads.put("lekki", Arrays.asList("Lekki-Epe Expressway", "Admiralty Way", "Ajah Road"));
        roads.put("vi", Arrays.asList("Ozumba Mbadiwe", "Adeola Odeku", "Ahmadu Bello"));
        roads.put("ikeja", Arrays.asList("Allen Avenue", "Awolowo Way", "Oba Akran"));
        
        List<String> localRoads = roads.getOrDefault(location.toLowerCase(), 
                                                      Arrays.asList("Main Road", "Service Lane"));
        return localRoads.get(Math.min(index - 1, localRoads.size() - 1));
    }
    
    private String capitalize(String str) {
        if (str == null || str.isEmpty()) return str;
        return str.substring(0, 1).toUpperCase() + str.substring(1);
    }
    
    // Inner classes
    static class UserPreference {
        boolean alertsEnabled;
        List<String> favoriteRoutes;
        
        UserPreference(boolean alerts) {
            this.alertsEnabled = alerts;
            this.favoriteRoutes = new ArrayList<>();
        }
    }
    
    public static class TrafficAlert {
        public final String location;
        public final String description;
        public final String severity;
        public final String estimatedDuration;
        public final LocalDateTime timestamp;
        
        public TrafficAlert(String location, String description, String severity, String duration) {
            this.location = location;
            this.description = description;
            this.severity = severity;
            this.estimatedDuration = duration;
            this.timestamp = LocalDateTime.now();
        }
    }
}