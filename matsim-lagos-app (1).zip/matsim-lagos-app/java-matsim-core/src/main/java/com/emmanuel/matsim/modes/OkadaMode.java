package com.emmanuel.matsim.modes;

import org.matsim.api.core.v01.Coord;
import org.matsim.api.core.v01.Id;
import org.matsim.api.core.v01.Scenario;
import org.matsim.api.core.v01.network.Link;
import org.matsim.api.core.v01.network.Network;
import org.matsim.api.core.v01.population.*;
import org.matsim.core.config.Config;
import org.matsim.core.config.groups.PlanCalcScoreConfigGroup;
import org.matsim.core.config.groups.PlansCalcRouteConfigGroup;
import org.matsim.core.router.RoutingModule;
import org.matsim.core.router.costcalculators.TravelDisutilityFactory;
import org.matsim.core.router.util.TravelTime;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.*;

/**
 * Okada (Motorcycle) Transport Mode for Lagos
 * 
 * Characteristics:
 * - Can navigate through traffic (lane splitting)
 * - Faster in congested conditions
 * - Weather-sensitive (dangerous in rain)
 * - Restricted on certain highways (Third Mainland Bridge, Lekki-Epe)
 * - Popular for last-mile connectivity
 */
public class OkadaMode {
    private static final Logger log = LogManager.getLogger(OkadaMode.class);
    
    public static final String MODE_NAME = "okada";
    
    // Okada characteristics
    private static final double MAX_SPEED_KMH = 80.0; // Maximum speed
    private static final double TYPICAL_SPEED_KMH = 40.0; // Typical urban speed
    private static final double CONGESTION_ADVANTAGE = 0.4; // 40% faster in traffic
    private static final double RAIN_PENALTY = 0.5; // 50% slower in rain
    private static final double PASSENGER_CAPACITY = 1.0; // One passenger
    private static final double COST_PER_KM = 50.0; // Naira per kilometer
    private static final double BASE_FARE = 100.0; // Minimum fare in Naira
    
    // Restricted areas in Lagos
    private static final Set<String> RESTRICTED_AREAS = new HashSet<>(Arrays.asList(
        "Third Mainland Bridge",
        "Lekki-Epe Expressway",
        "Lagos-Ibadan Expressway",
        "Apapa-Oshodi Expressway",
        "Victoria Island", // After 2012 ban
        "Ikoyi",
        "Lagos Island CBD"
    ));
    
    // Okada parks/stands locations
    private static final List<OkadaPark> OKADA_PARKS = Arrays.asList(
        new OkadaPark("Oshodi Under Bridge", new Coord(3.3454, 6.5512), 150),
        new OkadaPark("Ikeja Along", new Coord(3.3423, 6.6012), 100),
        new OkadaPark("Yaba Bus Stop", new Coord(3.3773, 6.5012), 120),
        new OkadaPark("Ojuelegba", new Coord(3.3642, 6.5043), 80),
        new OkadaPark("Agege Motor Road", new Coord(3.3234, 6.6154), 90),
        new OkadaPark("Mushin", new Coord(3.3489, 6.5273), 110),
        new OkadaPark("Mile 2", new Coord(3.3294, 6.4582), 75),
        new OkadaPark("Ojota", new Coord(3.3818, 6.5858), 95),
        new OkadaPark("Ketu", new Coord(3.3856, 6.5980), 60),
        new OkadaPark("Iyana Ipaja", new Coord(3.2756, 6.6180), 85)
    );
    
    /**
     * Configure Okada mode in MATSim config
     */
    public static void configureOkadaMode(Config config) {
        log.info("Configuring Okada (motorcycle) mode for Lagos");
        
        // Add okada as a network mode
        Set<String> networkModes = new HashSet<>(config.plansCalcRoute().getNetworkModes());
        networkModes.add(MODE_NAME);
        config.plansCalcRoute().setNetworkModes(networkModes);
        
        // Configure scoring parameters
        PlanCalcScoreConfigGroup.ModeParams okadaParams = 
            new PlanCalcScoreConfigGroup.ModeParams(MODE_NAME);
        
        // Okada is less comfortable than car but faster in traffic
        okadaParams.setMarginalUtilityOfTraveling(-4.0); // Discomfort factor
        okadaParams.setMonetaryDistanceRate(-0.00005); // Cost per meter (50 Naira/km)
        okadaParams.setConstant(-2.0); // Mode-specific constant (safety concern)
        
        config.planCalcScore().addModeParams(okadaParams);
        
        // Teleported mode parameters (for areas where okada is banned)
        PlansCalcRouteConfigGroup.ModeRoutingParams okadaRouting = 
            new PlansCalcRouteConfigGroup.ModeRoutingParams(MODE_NAME);
        okadaRouting.setTeleportedModeSpeed(TYPICAL_SPEED_KMH / 3.6); // m/s
        okadaRouting.setBeelineDistanceFactor(1.3); // Account for actual road distance
        
        config.plansCalcRoute().addModeRoutingParams(okadaRouting);
        
        log.info("Okada mode configured with {} parks", OKADA_PARKS.size());
    }
    
    /**
     * Create Okada agents for simulation
     */
    public static void createOkadaAgents(Scenario scenario, int numberOfOkadas) {
        log.info("Creating {} Okada riders for simulation", numberOfOkadas);
        
        Population population = scenario.getPopulation();
        PopulationFactory factory = population.getFactory();
        Network network = scenario.getNetwork();
        
        int okadaPerPark = numberOfOkadas / OKADA_PARKS.size();
        int okadaCount = 0;
        
        for (OkadaPark park : OKADA_PARKS) {
            for (int i = 0; i < okadaPerPark && okadaCount < numberOfOkadas; i++) {
                Person okadaRider = factory.createPerson(
                    Id.createPersonId("okada_" + park.name.replace(" ", "_") + "_" + i));
                
                Plan plan = factory.createPlan();
                
                // Okada daily pattern: Wait at park -> Pick passenger -> Drop -> Return
                // Start at park (5:30 AM)
                Activity parkWait = factory.createActivityFromCoord("okada_park", park.location);
                parkWait.setEndTime(5.5 * 3600 + Math.random() * 3600); // 5:30-6:30 AM
                plan.addActivity(parkWait);
                
                // Multiple trips throughout the day
                for (int trip = 0; trip < 15; trip++) { // Average 15 trips per day
                    // Pick up passenger
                    Coord pickupLocation = generateRandomLocation(park.location, 2000); // 2km radius
                    Leg toPickup = factory.createLeg(MODE_NAME);
                    plan.addLeg(toPickup);
                    
                    Activity pickup = factory.createActivityFromCoord("okada_pickup", pickupLocation);
                    pickup.setMaximumDuration(60); // 1 minute wait
                    plan.addActivity(pickup);
                    
                    // Transport passenger
                    Coord dropLocation = generateRandomLocation(pickupLocation, 5000); // 5km average trip
                    Leg toDropoff = factory.createLeg(MODE_NAME);
                    plan.addLeg(toDropoff);
                    
                    Activity dropoff = factory.createActivityFromCoord("okada_dropoff", dropLocation);
                    dropoff.setMaximumDuration(30); // 30 seconds
                    plan.addActivity(dropoff);
                    
                    // Return to park or find new passenger
                    if (Math.random() < 0.3) { // 30% chance to return to park
                        Leg toPark = factory.createLeg(MODE_NAME);
                        plan.addLeg(toPark);
                        
                        Activity parkRest = factory.createActivityFromCoord("okada_park", park.location);
                        parkRest.setMaximumDuration(10 * 60); // 10 minute rest
                        plan.addActivity(parkRest);
                    }
                }
                
                // End of day - return to park
                Leg finalReturn = factory.createLeg(MODE_NAME);
                plan.addLeg(finalReturn);
                
                Activity parkEnd = factory.createActivityFromCoord("okada_park", park.location);
                plan.addActivity(parkEnd);
                
                okadaRider.addPlan(plan);
                okadaRider.setSelectedPlan(plan);
                
                // Set attributes
                PersonUtils.setAge(okadaRider, 20 + (int)(Math.random() * 25)); // 20-45 years
                PersonUtils.setSex(okadaRider, "m"); // Predominantly male
                PersonUtils.setEmployed(okadaRider, true);
                PersonUtils.setCarAvail(okadaRider, "never");
                
                population.addPerson(okadaRider);
                okadaCount++;
            }
        }
        
        log.info("Created {} Okada riders across {} parks", okadaCount, OKADA_PARKS.size());
    }
    
    /**
     * Calculate Okada travel time considering traffic and weather
     */
    public static double calculateOkadaTravelTime(
            double distance, 
            double congestionLevel, 
            boolean isRaining,
            boolean isRestrictedArea) {
        
        if (isRestrictedArea) {
            // Okada banned - return very high travel time to discourage
            return Double.MAX_VALUE;
        }
        
        double baseSpeed = TYPICAL_SPEED_KMH / 3.6; // Convert to m/s
        
        // Advantage in congestion (can weave through traffic)
        double congestionFactor = 1.0 - (congestionLevel * (1.0 - CONGESTION_ADVANTAGE));
        
        // Disadvantage in rain
        double weatherFactor = isRaining ? (1.0 - RAIN_PENALTY) : 1.0;
        
        double effectiveSpeed = baseSpeed * congestionFactor * weatherFactor;
        
        return distance / effectiveSpeed; // Time in seconds
    }
    
    /**
     * Calculate Okada fare
     */
    public static double calculateOkadaFare(double distance) {
        double distanceKm = distance / 1000.0;
        double fare = BASE_FARE + (COST_PER_KM * distanceKm);
        
        // Round to nearest 50 Naira (common practice)
        return Math.round(fare / 50.0) * 50.0;
    }
    
    /**
     * Check if area is restricted for Okada
     */
    public static boolean isRestrictedArea(String areaName, Coord location) {
        // Check by area name
        for (String restricted : RESTRICTED_AREAS) {
            if (areaName != null && areaName.contains(restricted)) {
                return true;
            }
        }
        
        // Check specific coordinates (Victoria Island, Ikoyi, Lagos Island)
        // Approximate boundaries
        double lon = location.getX();
        double lat = location.getY();
        
        // Victoria Island boundaries (approximate)
        if (lon >= 3.40 && lon <= 3.45 && lat >= 6.42 && lat <= 6.46) {
            return true;
        }
        
        // Ikoyi boundaries (approximate)
        if (lon >= 3.43 && lon <= 3.48 && lat >= 6.44 && lat <= 6.47) {
            return true;
        }
        
        return false;
    }
    
    /**
     * Generate random location within radius
     */
    private static Coord generateRandomLocation(Coord center, double radiusMeters) {
        Random random = new Random();
        double angle = random.nextDouble() * 2 * Math.PI;
        double distance = random.nextDouble() * radiusMeters;
        
        // Approximate conversion (1 degree ≈ 111km at equator)
        double deltaLon = (distance * Math.cos(angle)) / 111000.0;
        double deltaLat = (distance * Math.sin(angle)) / 111000.0;
        
        return new Coord(
            center.getX() + deltaLon,
            center.getY() + deltaLat
        );
    }
    
    /**
     * Okada Park/Stand location
     */
    public static class OkadaPark {
        public final String name;
        public final Coord location;
        public final int capacity;
        
        public OkadaPark(String name, Coord location, int capacity) {
            this.name = name;
            this.location = location;
            this.capacity = capacity;
        }
    }
    
    /**
     * Okada-specific event handler for tracking
     */
    public static class OkadaEventHandler {
        private int okadaTrips = 0;
        private double totalDistance = 0;
        private double totalRevenue = 0;
        private int accidentsInRain = 0;
        
        public void handleOkadaTrip(double distance, boolean isRaining) {
            okadaTrips++;
            totalDistance += distance;
            totalRevenue += calculateOkadaFare(distance);
            
            // Accident probability (higher in rain)
            double accidentProb = isRaining ? 0.02 : 0.005; // 2% vs 0.5%
            if (Math.random() < accidentProb) {
                accidentsInRain++;
                log.warn("Okada accident occurred" + (isRaining ? " in rain" : ""));
            }
        }
        
        public void printStatistics() {
            log.info("=== Okada Statistics ===");
            log.info("Total trips: {}", okadaTrips);
            log.info("Total distance: {:.2f} km", totalDistance / 1000);
            log.info("Total revenue: ₦{:.0f}", totalRevenue);
            log.info("Average fare: ₦{:.0f}", totalRevenue / Math.max(1, okadaTrips));
            log.info("Accidents: {}", accidentsInRain);
        }
    }
}