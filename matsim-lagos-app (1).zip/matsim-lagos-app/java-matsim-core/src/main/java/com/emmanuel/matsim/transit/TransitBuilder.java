package com.emmanuel.matsim.transit;

import org.matsim.api.core.v01.Coord;
import org.matsim.api.core.v01.Id;
import org.matsim.api.core.v01.Scenario;
import org.matsim.api.core.v01.network.Link;
import org.matsim.api.core.v01.network.Network;
import org.matsim.core.population.routes.NetworkRoute;
import org.matsim.core.population.routes.RouteUtils;
import org.matsim.core.utils.geometry.CoordinateTransformation;
import org.matsim.core.utils.geometry.transformations.TransformationFactory;
import org.matsim.pt.transitSchedule.api.*;
import org.matsim.vehicles.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

public class TransitBuilder {
    private static final Logger log = LogManager.getLogger(TransitBuilder.class);
    private final Scenario scenario;
    private final TransitSchedule schedule;
    private final TransitScheduleFactory scheduleFactory;
    private final Vehicles transitVehicles;
    private final VehiclesFactory vehiclesFactory;
    private final Network network;
    private final CoordinateTransformation ct;
    
    private static final String CRS_LAGOS = "EPSG:32631";
    
    public TransitBuilder(Scenario scenario) {
        this.scenario = scenario;
        this.schedule = scenario.getTransitSchedule();
        this.scheduleFactory = schedule.getFactory();
        this.transitVehicles = scenario.getTransitVehicles();
        this.vehiclesFactory = transitVehicles.getFactory();
        this.network = scenario.getNetwork();
        this.ct = TransformationFactory.getCoordinateTransformation(
                TransformationFactory.WGS84, CRS_LAGOS);
    }
    
    public void buildTransitLines() {
        log.info("Building transit lines for Lagos (BRT and Danfo routes)");
        
        createBRTLine1();
        createBRTLine2();
        createDanfoRoute1();
        createDanfoRoute2();
        createDanfoRoute3();
        
        log.info("Created {} transit lines with {} stops", 
                schedule.getTransitLines().size(),
                schedule.getFacilities().size());
    }
    
    private void createBRTLine1() {
        String lineId = "BRT_Line1_CMS_Mile2";
        
        List<TransitStopFacility> stops = new ArrayList<>();
        stops.add(createStop("CMS", new Coord(3.3965, 6.4531)));
        stops.add(createStop("National_Theatre", new Coord(3.3775, 6.4834)));
        stops.add(createStop("Iponri", new Coord(3.3623, 6.4886)));
        stops.add(createStop("Costain", new Coord(3.3571, 6.4901)));
        stops.add(createStop("Ojuelegba", new Coord(3.3642, 6.5043)));
        stops.add(createStop("Mile2", new Coord(3.3294, 6.4582)));
        
        TransitLine transitLine = scheduleFactory.createTransitLine(Id.create(lineId, TransitLine.class));
        
        NetworkRoute networkRoute = createNetworkRoute(stops);
        TransitRoute transitRoute = scheduleFactory.createTransitRoute(
                Id.create(lineId + "_route1", TransitRoute.class),
                networkRoute,
                createRouteStops(stops),
                TransportMode.pt);
        
        transitRoute.setDescription("BRT Line from CMS to Mile 2");
        
        for (int i = 0; i < 20; i++) {
            double departureTime = 6 * 3600 + i * 15 * 60;
            Departure departure = scheduleFactory.createDeparture(
                    Id.create(lineId + "_dep_" + i, Departure.class),
                    departureTime);
            
            Id<Vehicle> vehicleId = Id.create("BRT_" + lineId + "_veh_" + i, Vehicle.class);
            departure.setVehicleId(vehicleId);
            transitRoute.addDeparture(departure);
            
            createBRTVehicle(vehicleId);
        }
        
        transitLine.addRoute(transitRoute);
        schedule.addTransitLine(transitLine);
        log.info("Created BRT Line 1: CMS to Mile 2");
    }
    
    private void createBRTLine2() {
        String lineId = "BRT_Line2_Oshodi_VI";
        
        List<TransitStopFacility> stops = new ArrayList<>();
        stops.add(createStop("Oshodi", new Coord(3.3454, 6.5512)));
        stops.add(createStop("Maryland", new Coord(3.3666, 6.5678)));
        stops.add(createStop("Ojota", new Coord(3.3818, 6.5858)));
        stops.add(createStop("Obalende", new Coord(3.4084, 6.4493)));
        stops.add(createStop("Victoria_Island", new Coord(3.4247, 6.4281)));
        
        TransitLine transitLine = scheduleFactory.createTransitLine(Id.create(lineId, TransitLine.class));
        
        NetworkRoute networkRoute = createNetworkRoute(stops);
        TransitRoute transitRoute = scheduleFactory.createTransitRoute(
                Id.create(lineId + "_route1", TransitRoute.class),
                networkRoute,
                createRouteStops(stops),
                TransportMode.pt);
        
        for (int i = 0; i < 15; i++) {
            double departureTime = 6 * 3600 + i * 20 * 60;
            Departure departure = scheduleFactory.createDeparture(
                    Id.create(lineId + "_dep_" + i, Departure.class),
                    departureTime);
            
            Id<Vehicle> vehicleId = Id.create("BRT_" + lineId + "_veh_" + i, Vehicle.class);
            departure.setVehicleId(vehicleId);
            transitRoute.addDeparture(departure);
            
            createBRTVehicle(vehicleId);
        }
        
        transitLine.addRoute(transitRoute);
        schedule.addTransitLine(transitLine);
        log.info("Created BRT Line 2: Oshodi to Victoria Island");
    }
    
    private void createDanfoRoute1() {
        String lineId = "Danfo_Route1_Yaba_Surulere";
        
        List<TransitStopFacility> stops = new ArrayList<>();
        stops.add(createStop("Yaba", new Coord(3.3773, 6.5012)));
        stops.add(createStop("Jibowu", new Coord(3.3681, 6.5161)));
        stops.add(createStop("Surulere", new Coord(3.3574, 6.4973)));
        
        createDanfoLine(lineId, stops, 30, 10);
        log.info("Created Danfo Route 1: Yaba to Surulere");
    }
    
    private void createDanfoRoute2() {
        String lineId = "Danfo_Route2_Ikeja_Agege";
        
        List<TransitStopFacility> stops = new ArrayList<>();
        stops.add(createStop("Ikeja", new Coord(3.3423, 6.6012)));
        stops.add(createStop("Ogba", new Coord(3.3456, 6.6234)));
        stops.add(createStop("Agege", new Coord(3.3234, 6.6154)));
        
        createDanfoLine(lineId, stops, 25, 12);
        log.info("Created Danfo Route 2: Ikeja to Agege");
    }
    
    private void createDanfoRoute3() {
        String lineId = "Danfo_Route3_Apapa_Marina";
        
        List<TransitStopFacility> stops = new ArrayList<>();
        stops.add(createStop("Apapa", new Coord(3.3589, 6.4444)));
        stops.add(createStop("Tincan", new Coord(3.3456, 6.4367)));
        stops.add(createStop("Marina", new Coord(3.3965, 6.4484)));
        
        createDanfoLine(lineId, stops, 20, 8);
        log.info("Created Danfo Route 3: Apapa to Marina");
    }
    
    private void createDanfoLine(String lineId, List<TransitStopFacility> stops, int numVehicles, int headwayMinutes) {
        TransitLine transitLine = scheduleFactory.createTransitLine(Id.create(lineId, TransitLine.class));
        
        NetworkRoute networkRoute = createNetworkRoute(stops);
        TransitRoute transitRoute = scheduleFactory.createTransitRoute(
                Id.create(lineId + "_route1", TransitRoute.class),
                networkRoute,
                createRouteStops(stops),
                TransportMode.pt);
        
        for (int i = 0; i < numVehicles; i++) {
            double departureTime = 5.5 * 3600 + i * headwayMinutes * 60;
            Departure departure = scheduleFactory.createDeparture(
                    Id.create(lineId + "_dep_" + i, Departure.class),
                    departureTime);
            
            Id<Vehicle> vehicleId = Id.create("Danfo_" + lineId + "_veh_" + i, Vehicle.class);
            departure.setVehicleId(vehicleId);
            transitRoute.addDeparture(departure);
            
            createDanfoVehicle(vehicleId);
        }
        
        transitLine.addRoute(transitRoute);
        schedule.addTransitLine(transitLine);
    }
    
    private TransitStopFacility createStop(String stopName, Coord wgs84Coord) {
        Coord transformedCoord = ct.transform(wgs84Coord);
        Id<TransitStopFacility> stopId = Id.create(stopName, TransitStopFacility.class);
        
        if (schedule.getFacilities().containsKey(stopId)) {
            return schedule.getFacilities().get(stopId);
        }
        
        TransitStopFacility stop = scheduleFactory.createTransitStopFacility(
                stopId, transformedCoord, false);
        stop.setName(stopName);
        
        Link nearestLink = findNearestLink(transformedCoord);
        if (nearestLink != null) {
            stop.setLinkId(nearestLink.getId());
        }
        
        schedule.addStopFacility(stop);
        return stop;
    }
    
    private Link findNearestLink(Coord coord) {
        Link nearestLink = null;
        double minDistance = Double.MAX_VALUE;
        
        for (Link link : network.getLinks().values()) {
            double distance = calculateDistance(coord, link.getCoord());
            if (distance < minDistance) {
                minDistance = distance;
                nearestLink = link;
            }
        }
        
        return nearestLink;
    }
    
    private double calculateDistance(Coord c1, Coord c2) {
        double dx = c1.getX() - c2.getX();
        double dy = c1.getY() - c2.getY();
        return Math.sqrt(dx * dx + dy * dy);
    }
    
    private NetworkRoute createNetworkRoute(List<TransitStopFacility> stops) {
        List<Id<Link>> linkIds = new ArrayList<>();
        for (TransitStopFacility stop : stops) {
            if (stop.getLinkId() != null) {
                linkIds.add(stop.getLinkId());
            }
        }
        
        if (linkIds.size() >= 2) {
            return RouteUtils.createNetworkRoute(linkIds, network);
        }
        return null;
    }
    
    private List<TransitRouteStop> createRouteStops(List<TransitStopFacility> stops) {
        List<TransitRouteStop> routeStops = new ArrayList<>();
        double time = 0;
        
        for (int i = 0; i < stops.size(); i++) {
            TransitRouteStop routeStop = scheduleFactory.createTransitRouteStop(
                    stops.get(i),
                    time,
                    time + 30);
            routeStops.add(routeStop);
            time += 5 * 60;
        }
        
        return routeStops;
    }
    
    private void createBRTVehicle(Id<Vehicle> vehicleId) {
        VehicleType brtType = vehiclesFactory.createVehicleType(Id.create("BRT", VehicleType.class));
        brtType.getCapacity().setSeats(60);
        brtType.getCapacity().setStandingRoom(40);
        brtType.setLength(18.0);
        brtType.setMaximumVelocity(80.0 / 3.6);
        
        if (!transitVehicles.getVehicleTypes().containsKey(brtType.getId())) {
            transitVehicles.addVehicleType(brtType);
        }
        
        Vehicle vehicle = vehiclesFactory.createVehicle(vehicleId, brtType);
        transitVehicles.addVehicle(vehicle);
    }
    
    private void createDanfoVehicle(Id<Vehicle> vehicleId) {
        VehicleType danfoType = vehiclesFactory.createVehicleType(Id.create("Danfo", VehicleType.class));
        danfoType.getCapacity().setSeats(14);
        danfoType.getCapacity().setStandingRoom(4);
        danfoType.setLength(5.5);
        danfoType.setMaximumVelocity(60.0 / 3.6);
        
        if (!transitVehicles.getVehicleTypes().containsKey(danfoType.getId())) {
            transitVehicles.addVehicleType(danfoType);
        }
        
        Vehicle vehicle = vehiclesFactory.createVehicle(vehicleId, danfoType);
        transitVehicles.addVehicle(vehicle);
    }
    
    public void writeTransitSchedule(String outputFile) {
        TransitScheduleWriter writer = new TransitScheduleWriter(schedule);
        writer.writeFile(outputFile);
        log.info("Transit schedule written to: {}", outputFile);
    }
    
    public void writeTransitVehicles(String outputFile) {
        VehicleWriterV1 writer = new VehicleWriterV1(transitVehicles);
        writer.writeFile(outputFile);
        log.info("Transit vehicles written to: {}", outputFile);
    }
}