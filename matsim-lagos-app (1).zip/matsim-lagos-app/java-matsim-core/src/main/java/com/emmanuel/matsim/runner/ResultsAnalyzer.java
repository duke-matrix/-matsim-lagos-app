package com.emmanuel.matsim.runner;

import org.matsim.api.core.v01.events.*;
import org.matsim.api.core.v01.events.handler.*;
import org.matsim.core.api.experimental.events.EventsManager;
import org.matsim.core.events.EventsUtils;
import org.matsim.core.events.MatsimEventsReader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class ResultsAnalyzer implements PersonArrivalEventHandler, PersonDepartureEventHandler, 
        ActivityStartEventHandler, ActivityEndEventHandler, PersonEntersVehicleEventHandler {
    
    private static final Logger log = LogManager.getLogger(ResultsAnalyzer.class);
    
    private final String outputDirectory;
    private final int iteration;
    
    private Map<String, Integer> modalSplit = new HashMap<>();
    private Map<String, Double> travelTimes = new HashMap<>();
    private Map<String, Double> departureTimes = new HashMap<>();
    private Map<String, List<Double>> activityDurations = new HashMap<>();
    private int totalTrips = 0;
    private double totalTravelTime = 0;
    private List<Double> agentScores = new ArrayList<>();
    
    public ResultsAnalyzer(String outputDirectory, int iteration) {
        this.outputDirectory = outputDirectory;
        this.iteration = iteration;
    }
    
    public void calculateModalSplit() {
        log.info("Calculating modal split for iteration {}", iteration);
        
        String eventsFile = outputDirectory + "/ITERS/it." + iteration + "/" + iteration + ".events.xml.gz";
        
        EventsManager eventsManager = EventsUtils.createEventsManager();
        eventsManager.addHandler(this);
        
        MatsimEventsReader eventsReader = new MatsimEventsReader(eventsManager);
        eventsReader.readFile(eventsFile);
        
        printModalSplit();
    }
    
    public void analyzeTravelTimes() {
        log.info("Analyzing travel times");
        
        if (travelTimes.isEmpty()) {
            return;
        }
        
        double avgTravelTime = totalTravelTime / travelTimes.size();
        double maxTravelTime = Collections.max(travelTimes.values());
        double minTravelTime = Collections.min(travelTimes.values());
        
        log.info("Average travel time: {} minutes", avgTravelTime / 60);
        log.info("Maximum travel time: {} minutes", maxTravelTime / 60);
        log.info("Minimum travel time: {} minutes", minTravelTime / 60);
    }
    
    public void evaluateAgentScores() {
        log.info("Evaluating agent scores");
        
        String plansFile = outputDirectory + "/ITERS/it." + iteration + "/" + iteration + ".plans.xml.gz";
        
        try {
            org.matsim.api.core.v01.population.Population population = 
                org.matsim.core.population.io.PopulationReader.readPopulation(plansFile);
            
            for (org.matsim.api.core.v01.population.Person person : population.getPersons().values()) {
                if (person.getSelectedPlan() != null && person.getSelectedPlan().getScore() != null) {
                    agentScores.add(person.getSelectedPlan().getScore());
                }
            }
            
            if (!agentScores.isEmpty()) {
                double avgScore = agentScores.stream().mapToDouble(Double::doubleValue).average().orElse(0);
                double maxScore = Collections.max(agentScores);
                double minScore = Collections.min(agentScores);
                
                log.info("Average agent score: {}", avgScore);
                log.info("Maximum agent score: {}", maxScore);
                log.info("Minimum agent score: {}", minScore);
            }
        } catch (Exception e) {
            log.warn("Could not read plans file: {}", e.getMessage());
        }
    }
    
    public void generateSummaryReport() {
        log.info("Generating summary report");
        
        String reportFile = outputDirectory + "/lagos_simulation_summary.txt";
        
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(reportFile))) {
            writer.write("========================================\n");
            writer.write("LAGOS MATSIM SIMULATION SUMMARY REPORT\n");
            writer.write("========================================\n\n");
            
            writer.write("Simulation Parameters:\n");
            writer.write("----------------------\n");
            writer.write("Final Iteration: " + iteration + "\n");
            writer.write("Output Directory: " + outputDirectory + "\n\n");
            
            writer.write("Modal Split:\n");
            writer.write("------------\n");
            for (Map.Entry<String, Integer> entry : modalSplit.entrySet()) {
                double percentage = (entry.getValue() * 100.0) / totalTrips;
                writer.write(String.format("%s: %.2f%% (%d trips)\n", 
                    entry.getKey(), percentage, entry.getValue()));
            }
            writer.write("Total trips: " + totalTrips + "\n\n");
            
            writer.write("Travel Time Statistics:\n");
            writer.write("----------------------\n");
            if (!travelTimes.isEmpty()) {
                double avgTravelTime = totalTravelTime / travelTimes.size();
                writer.write(String.format("Average: %.2f minutes\n", avgTravelTime / 60));
                writer.write(String.format("Maximum: %.2f minutes\n", 
                    Collections.max(travelTimes.values()) / 60));
                writer.write(String.format("Minimum: %.2f minutes\n", 
                    Collections.min(travelTimes.values()) / 60));
            }
            
            writer.write("\nAgent Score Statistics:\n");
            writer.write("----------------------\n");
            if (!agentScores.isEmpty()) {
                double avgScore = agentScores.stream().mapToDouble(Double::doubleValue).average().orElse(0);
                writer.write(String.format("Average: %.2f\n", avgScore));
                writer.write(String.format("Maximum: %.2f\n", Collections.max(agentScores)));
                writer.write(String.format("Minimum: %.2f\n", Collections.min(agentScores)));
                writer.write("Total agents analyzed: " + agentScores.size() + "\n");
            }
            
            writer.write("\nActivity Durations:\n");
            writer.write("------------------\n");
            for (Map.Entry<String, List<Double>> entry : activityDurations.entrySet()) {
                if (!entry.getValue().isEmpty()) {
                    double avgDuration = entry.getValue().stream()
                        .mapToDouble(Double::doubleValue).average().orElse(0);
                    writer.write(String.format("%s: %.2f hours\n", 
                        entry.getKey(), avgDuration / 3600));
                }
            }
            
            writer.write("\n========================================\n");
            writer.write("Report generated successfully\n");
            writer.write("========================================\n");
            
            log.info("Summary report written to: {}", reportFile);
            
        } catch (IOException e) {
            log.error("Error writing summary report: ", e);
        }
    }
    
    private void printModalSplit() {
        log.info("Modal Split Results:");
        for (Map.Entry<String, Integer> entry : modalSplit.entrySet()) {
            double percentage = (entry.getValue() * 100.0) / totalTrips;
            log.info("{}: {:.2f}% ({} trips)", entry.getKey(), percentage, entry.getValue());
        }
    }
    
    @Override
    public void handleEvent(PersonDepartureEvent event) {
        String mode = event.getLegMode();
        modalSplit.merge(mode, 1, Integer::sum);
        totalTrips++;
        departureTimes.put(event.getPersonId().toString(), event.getTime());
    }
    
    @Override
    public void handleEvent(PersonArrivalEvent event) {
        String personId = event.getPersonId().toString();
        if (departureTimes.containsKey(personId)) {
            double travelTime = event.getTime() - departureTimes.get(personId);
            travelTimes.put(personId, travelTime);
            totalTravelTime += travelTime;
            departureTimes.remove(personId);
        }
    }
    
    @Override
    public void handleEvent(ActivityStartEvent event) {
        String actType = event.getActType();
        if (!actType.contains("interaction")) {
            activityDurations.putIfAbsent(actType, new ArrayList<>());
        }
    }
    
    @Override
    public void handleEvent(ActivityEndEvent event) {
        String actType = event.getActType();
        if (!actType.contains("interaction") && activityDurations.containsKey(actType)) {
            double duration = event.getTime();
            activityDurations.get(actType).add(duration);
        }
    }
    
    @Override
    public void handleEvent(PersonEntersVehicleEvent event) {
    }
}