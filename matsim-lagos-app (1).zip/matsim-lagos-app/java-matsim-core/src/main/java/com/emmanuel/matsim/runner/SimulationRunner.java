package com.emmanuel.matsim.runner;

import com.emmanuel.matsim.config.AppConfig;
import com.emmanuel.matsim.network.NetworkBuilder;
import com.emmanuel.matsim.population.PopulationBuilder;
import com.emmanuel.matsim.transit.TransitBuilder;
import com.emmanuel.matsim.utils.ResultsAnalyzer;
import com.emmanuel.matsim.modes.OkadaMode;
import com.emmanuel.matsim.weather.WeatherImpactModel;
import org.matsim.api.core.v01.Scenario;
import org.matsim.api.core.v01.TransportMode;
import org.matsim.core.config.Config;
import org.matsim.core.config.ConfigUtils;
import org.matsim.core.config.groups.*;
import org.matsim.core.controler.Controler;
import org.matsim.core.controler.OutputDirectoryHierarchy;
import org.matsim.core.scenario.ScenarioUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.time.LocalDate;

public class SimulationRunner {
    private static final Logger log = LogManager.getLogger(SimulationRunner.class);
    private final AppConfig cfg;
    private String outputDir;
    private String networkFile;
    private String populationFile;
    private String transitScheduleFile;
    private String transitVehiclesFile;
    
    public SimulationRunner(AppConfig config) {
        this.cfg = config;
        this.outputDir = cfg.getOutputDir();
        this.networkFile = outputDir + "/network.xml.gz";
        this.populationFile = outputDir + "/population.xml.gz";
        this.transitScheduleFile = outputDir + "/transit-schedule.xml.gz";
        this.transitVehiclesFile = outputDir + "/transit-vehicles.xml.gz";
    }
    
    public static void main(String[] args) {
        AppConfig config = AppConfig.getInstance();
        config.parseArgs(args);
        
        log.info("=== MATSim Lagos Simulation ===");
        log.info("Population: {}", config.getPopulationSize());
        log.info("Iterations: {}", config.getIterations());
        log.info("Okada: {}", config.isOkadaEnabled() ? "Enabled" : "Disabled");
        log.info("Weather: {}", config.isWeatherEnabled() ? "Enabled" : "Disabled");
        
        SimulationRunner runner = new SimulationRunner(config);
        runner.run();
    }
    
    public void run() {
        Config config = createConfig();
        Scenario scenario = ScenarioUtils.loadScenario(config);
        
        // Ensure output directory exists
        new File(outputDir).mkdirs();
        
        if (!new File(networkFile).exists()) {
            log.info("Building network...");
            buildNetwork(scenario);
        }
        
        if (!new File(populationFile).exists()) {
            log.info("Creating population of {} agents", cfg.getPopulationSize());
            createPopulation(scenario);
        }
        
        if (!new File(transitScheduleFile).exists()) {
            log.info("Transit schedule not found. Building transit system...");
            buildTransit(scenario);
        }
        
        runSimulation(scenario);
        
        log.info("Simulation completed successfully!");
        log.info("Results saved to: {}", OUTPUT_DIR);

        // Run post-simulation analysis and reporting
        ResultsAnalyzer analyzer = new ResultsAnalyzer(OUTPUT_DIR, config.controler().getLastIteration());
        analyzer.calculateModalSplit();
        analyzer.analyzeTravelTimes();
        analyzer.evaluateAgentScores();
        analyzer.generateSummaryReport();
    }
    
    private Config createConfig() {
        Config config = ConfigUtils.createConfig();
        
        config.global().setCoordinateSystem("EPSG:32631");
        config.global().setRandomSeed(42);
        
        config.network().setInputFile(NETWORK_FILE);
        
        config.plans().setInputFile(POPULATION_FILE);
        
        config.transit().setUseTransit(true);
        config.transit().setTransitScheduleFile(TRANSIT_SCHEDULE_FILE);
        config.transit().setVehiclesFile(TRANSIT_VEHICLES_FILE);
        
        config.controler().setOutputDirectory(OUTPUT_DIR);
        config.controler().setFirstIteration(0);
        config.controler().setLastIteration(10);
        config.controler().setMobsim("qsim");
        config.controler().setWritePlansInterval(5);
        config.controler().setWriteEventsInterval(5);
        config.controler().setOverwriteFileSetting(
                OutputDirectoryHierarchy.OverwriteFileSetting.deleteDirectoryIfExists);
        
        QSimConfigGroup qsim = config.qsim();
        qsim.setStartTime(0);
        qsim.setEndTime(30 * 3600);
        qsim.setFlowCapFactor(0.1);
        qsim.setStorageCapFactor(0.3);
        qsim.setNumberOfThreads(4);
        qsim.setMainModes("car,bus");
        
        PlanCalcScoreConfigGroup.ActivityParams homeActivity = 
                new PlanCalcScoreConfigGroup.ActivityParams("home");
        homeActivity.setTypicalDuration(12 * 3600);
        homeActivity.setPriority(1.0);
        config.planCalcScore().addActivityParams(homeActivity);
        
        PlanCalcScoreConfigGroup.ActivityParams workActivity = 
                new PlanCalcScoreConfigGroup.ActivityParams("work");
        workActivity.setTypicalDuration(8 * 3600);
        workActivity.setOpeningTime(7 * 3600);
        workActivity.setClosingTime(20 * 3600);
        workActivity.setPriority(1.0);
        config.planCalcScore().addActivityParams(workActivity);
        
        PlanCalcScoreConfigGroup.ActivityParams marketActivity = 
                new PlanCalcScoreConfigGroup.ActivityParams("market");
        marketActivity.setTypicalDuration(1 * 3600);
        marketActivity.setOpeningTime(6 * 3600);
        marketActivity.setClosingTime(21 * 3600);
        marketActivity.setPriority(0.5);
        config.planCalcScore().addActivityParams(marketActivity);
        
        PlanCalcScoreConfigGroup.ActivityParams schoolActivity = 
                new PlanCalcScoreConfigGroup.ActivityParams("school");
        schoolActivity.setTypicalDuration(1.5 * 3600);
        schoolActivity.setOpeningTime(8 * 3600);
        schoolActivity.setClosingTime(18 * 3600);
        schoolActivity.setPriority(0.7);
        config.planCalcScore().addActivityParams(schoolActivity);
        
        PlanCalcScoreConfigGroup.ModeParams carMode = new PlanCalcScoreConfigGroup.ModeParams(TransportMode.car);
        carMode.setMarginalUtilityOfTraveling(-6.0);
        carMode.setMonetaryDistanceRate(-0.0003);
        config.planCalcScore().addModeParams(carMode);
        
        PlanCalcScoreConfigGroup.ModeParams ptMode = new PlanCalcScoreConfigGroup.ModeParams(TransportMode.pt);
        ptMode.setMarginalUtilityOfTraveling(-2.0);
        ptMode.setMonetaryDistanceRate(-0.0001);
        config.planCalcScore().addModeParams(ptMode);
        
        PlanCalcScoreConfigGroup.ModeParams walkMode = new PlanCalcScoreConfigGroup.ModeParams(TransportMode.walk);
        walkMode.setMarginalUtilityOfTraveling(0.0);
        config.planCalcScore().addModeParams(walkMode);
        
        config.planCalcScore().setPerforming_utils_hr(6.0);
        config.planCalcScore().setMarginalUtilityOfMoney(1.0);
        
        StrategyConfigGroup.StrategySettings reRoute = new StrategyConfigGroup.StrategySettings();
        reRoute.setStrategyName("ReRoute");
        reRoute.setWeight(0.3);
        config.strategy().addStrategySettings(reRoute);
        
        StrategyConfigGroup.StrategySettings changeMode = new StrategyConfigGroup.StrategySettings();
        changeMode.setStrategyName("ChangeSingleTripMode");
        changeMode.setWeight(0.1);
        config.strategy().addStrategySettings(changeMode);
        
        StrategyConfigGroup.StrategySettings selector = new StrategyConfigGroup.StrategySettings();
        selector.setStrategyName("ChangeExpBeta");
        selector.setWeight(0.6);
        config.strategy().addStrategySettings(selector);
        
        config.strategy().setMaxAgentPlanMemorySize(5);
        
        config.changeMode().setModes(new String[]{TransportMode.car, TransportMode.pt, TransportMode.walk});
        
        return config;
    }
    
    private void buildNetwork(Scenario scenario) {
        NetworkBuilder networkBuilder = new NetworkBuilder(
                "src/main/resources/lagos-sample.osm",
                NETWORK_FILE);
        
        try {
            createSampleOSMFile();
            networkBuilder.buildNetwork();
            networkBuilder.writeNetwork();
            scenario.setNetwork(networkBuilder.getNetwork());
        } catch (Exception e) {
            log.error("Error building network: ", e);
            log.info("Creating minimal synthetic network instead...");
            createMinimalNetwork(scenario);
        }
    }
    
    private void createPopulation(Scenario scenario) {
        PopulationBuilder populationBuilder = new PopulationBuilder(scenario);
        populationBuilder.createPopulation(1000);
        populationBuilder.writePopulation(POPULATION_FILE);
    }
    
    private void buildTransit(Scenario scenario) {
        TransitBuilder transitBuilder = new TransitBuilder(scenario);
        transitBuilder.buildTransitLines();
        transitBuilder.writeTransitSchedule(TRANSIT_SCHEDULE_FILE);
        transitBuilder.writeTransitVehicles(TRANSIT_VEHICLES_FILE);
    }
    
    private void runSimulation(Scenario scenario) {
        Controler controler = new Controler(scenario);
        
        controler.addOverridingModule(new org.matsim.core.controler.AbstractModule() {
            @Override
            public void install() {
                
            }
        });
        
        controler.run();
    }
    
    private void createSampleOSMFile() {
        String osmContent = "<?xml version='1.0' encoding='UTF-8'?>\n" +
                "<osm version='0.6' generator='Lagos Sample'>\n" +
                "  <bounds minlat='6.35' minlon='3.2' maxlat='6.7' maxlon='3.6'/>\n" +
                "  <node id='1' lat='6.4531' lon='3.3965'/>\n" +
                "  <node id='2' lat='6.5512' lon='3.3454'/>\n" +
                "  <node id='3' lat='6.4281' lon='3.4247'/>\n" +
                "  <node id='4' lat='6.6012' lon='3.3423'/>\n" +
                "  <node id='5' lat='6.4444' lon='3.3589'/>\n" +
                "  <way id='101'>\n" +
                "    <nd ref='1'/>\n" +
                "    <nd ref='2'/>\n" +
                "    <tag k='highway' v='primary'/>\n" +
                "    <tag k='name' v='Third Mainland Bridge'/>\n" +
                "  </way>\n" +
                "  <way id='102'>\n" +
                "    <nd ref='2'/>\n" +
                "    <nd ref='3'/>\n" +
                "    <tag k='highway' v='trunk'/>\n" +
                "    <tag k='name' v='Ikorodu Road'/>\n" +
                "  </way>\n" +
                "  <way id='103'>\n" +
                "    <nd ref='3'/>\n" +
                "    <nd ref='4'/>\n" +
                "    <tag k='highway' v='primary'/>\n" +
                "    <tag k='name' v='Lagos-Ibadan Expressway'/>\n" +
                "  </way>\n" +
                "</osm>";
        
        try {
            new File("src/main/resources").mkdirs();
            java.nio.file.Files.write(
                    java.nio.file.Paths.get("src/main/resources/lagos-sample.osm"),
                    osmContent.getBytes());
        } catch (Exception e) {
            log.warn("Could not create sample OSM file: {}", e.getMessage());
        }
    }
    
    private void createMinimalNetwork(Scenario scenario) {
        org.matsim.api.core.v01.network.NetworkFactory factory = scenario.getNetwork().getFactory();
        
        org.matsim.api.core.v01.network.Node n1 = factory.createNode(
                org.matsim.api.core.v01.Id.createNodeId("1"),
                new org.matsim.api.core.v01.Coord(0, 0));
        org.matsim.api.core.v01.network.Node n2 = factory.createNode(
                org.matsim.api.core.v01.Id.createNodeId("2"),
                new org.matsim.api.core.v01.Coord(1000, 0));
        org.matsim.api.core.v01.network.Node n3 = factory.createNode(
                org.matsim.api.core.v01.Id.createNodeId("3"),
                new org.matsim.api.core.v01.Coord(2000, 1000));
        org.matsim.api.core.v01.network.Node n4 = factory.createNode(
                org.matsim.api.core.v01.Id.createNodeId("4"),
                new org.matsim.api.core.v01.Coord(1000, 2000));
        
        scenario.getNetwork().addNode(n1);
        scenario.getNetwork().addNode(n2);
        scenario.getNetwork().addNode(n3);
        scenario.getNetwork().addNode(n4);
        
        org.matsim.api.core.v01.network.Link l1 = factory.createLink(
                org.matsim.api.core.v01.Id.createLinkId("1-2"),
                n1, n2);
        l1.setLength(1000);
        l1.setFreespeed(13.89);
        l1.setCapacity(2000);
        l1.setNumberOfLanes(2);
        
        org.matsim.api.core.v01.network.Link l2 = factory.createLink(
                org.matsim.api.core.v01.Id.createLinkId("2-3"),
                n2, n3);
        l2.setLength(1414);
        l2.setFreespeed(13.89);
        l2.setCapacity(2000);
        l2.setNumberOfLanes(2);
        
        scenario.getNetwork().addLink(l1);
        scenario.getNetwork().addLink(l2);
        
        new org.matsim.core.network.io.NetworkWriter(scenario.getNetwork()).write(NETWORK_FILE);
    }
}