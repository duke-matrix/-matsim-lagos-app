package com.emmanuel.matsim.web;

import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.*;
import java.net.InetSocketAddress;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;

public class WebServer {
    private static final Logger log = LogManager.getLogger(WebServer.class);
    private static final int PORT = 7878;
    private HttpServer server;
    private Map<String, Object> simulationData;
    
    public WebServer() {
        this.simulationData = new HashMap<>();
        initializeSimulationData();
    }
    
    private void initializeSimulationData() {
        simulationData.put("status", "running");
        simulationData.put("iteration", 0);
        simulationData.put("agents", 1000);
        simulationData.put("modalSplit", new double[]{30.0, 55.0, 15.0});
        simulationData.put("avgTravelTime", 38.6);
    }
    
    public void start() throws IOException {
        server = HttpServer.create(new InetSocketAddress(PORT), 0);
        
        server.createContext("/", new DashboardHandler());
        server.createContext("/api/status", new StatusHandler());
        server.createContext("/api/data", new DataHandler());
        server.createContext("/api/simulation/start", new SimulationStartHandler());
        server.createContext("/api/simulation/stop", new SimulationStopHandler());
        
        server.setExecutor(Executors.newFixedThreadPool(10));
        server.start();
        
        log.info("Web server started on http://localhost:{}", PORT);
        System.out.println("\n========================================");
        System.out.println("MATSim Lagos Web Dashboard");
        System.out.println("========================================");
        System.out.println("Server running at: http://localhost:" + PORT);
        System.out.println("Open your browser to view the dashboard");
        System.out.println("========================================\n");
    }
    
    public void stop() {
        if (server != null) {
            server.stop(0);
            log.info("Web server stopped");
        }
    }
    
    public void updateSimulationData(String key, Object value) {
        simulationData.put(key, value);
    }
    
    class DashboardHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String response = generateDashboardHTML();
            exchange.getResponseHeaders().set("Content-Type", "text/html");
            exchange.sendResponseHeaders(200, response.getBytes().length);
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(response.getBytes());
            }
        }
    }
    
    class StatusHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String status = (String) simulationData.get("status");
            String response = "{\"status\":\"" + status + "\"}";
            exchange.getResponseHeaders().set("Content-Type", "application/json");
            exchange.sendResponseHeaders(200, response.getBytes().length);
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(response.getBytes());
            }
        }
    }
    
    class DataHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String response = generateJsonData();
            exchange.getResponseHeaders().set("Content-Type", "application/json");
            exchange.sendResponseHeaders(200, response.getBytes().length);
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(response.getBytes());
            }
        }
    }
    
    class SimulationStartHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            simulationData.put("status", "running");
            String response = "{\"message\":\"Simulation started\"}";
            exchange.getResponseHeaders().set("Content-Type", "application/json");
            exchange.sendResponseHeaders(200, response.getBytes().length);
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(response.getBytes());
            }
        }
    }
    
    class SimulationStopHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            simulationData.put("status", "stopped");
            String response = "{\"message\":\"Simulation stopped\"}";
            exchange.getResponseHeaders().set("Content-Type", "application/json");
            exchange.sendResponseHeaders(200, response.getBytes().length);
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(response.getBytes());
            }
        }
    }
    
    private String generateJsonData() {
        double[] modalSplit = (double[]) simulationData.get("modalSplit");
        return String.format(
            "{\"agents\":%d,\"iteration\":%d,\"avgTravelTime\":%.1f," +
            "\"modalSplit\":{\"car\":%.1f,\"transit\":%.1f,\"walk\":%.1f}," +
            "\"network\":{\"nodes\":2847,\"links\":5234}," +
            "\"transit\":{\"lines\":5,\"stops\":15,\"vehicles\":85}}",
            simulationData.get("agents"),
            simulationData.get("iteration"),
            simulationData.get("avgTravelTime"),
            modalSplit[0], modalSplit[1], modalSplit[2]
        );
    }
    
    private String generateDashboardHTML() {
        return "<!DOCTYPE html>\n" +
            "<html lang=\"en\">\n" +
            "<head>\n" +
            "    <meta charset=\"UTF-8\">\n" +
            "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n" +
            "    <title>MATSim Lagos - Live Dashboard</title>\n" +
            "    <script src=\"https://cdn.jsdelivr.net/npm/chart.js\"></script>\n" +
            "    <style>\n" +
            "        * { margin: 0; padding: 0; box-sizing: border-box; }\n" +
            "        body {\n" +
            "            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;\n" +
            "            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);\n" +
            "            color: #333;\n" +
            "            min-height: 100vh;\n" +
            "        }\n" +
            "        .header {\n" +
            "            background: rgba(255, 255, 255, 0.95);\n" +
            "            padding: 20px;\n" +
            "            box-shadow: 0 2px 10px rgba(0,0,0,0.1);\n" +
            "        }\n" +
            "        .header h1 {\n" +
            "            color: #764ba2;\n" +
            "            display: flex;\n" +
            "            align-items: center;\n" +
            "            gap: 10px;\n" +
            "        }\n" +
            "        .status-badge {\n" +
            "            background: #10b981;\n" +
            "            color: white;\n" +
            "            padding: 5px 15px;\n" +
            "            border-radius: 20px;\n" +
            "            font-size: 14px;\n" +
            "            animation: pulse 2s infinite;\n" +
            "        }\n" +
            "        @keyframes pulse {\n" +
            "            0%, 100% { opacity: 1; }\n" +
            "            50% { opacity: 0.7; }\n" +
            "        }\n" +
            "        .container {\n" +
            "            max-width: 1400px;\n" +
            "            margin: 20px auto;\n" +
            "            padding: 0 20px;\n" +
            "        }\n" +
            "        .grid {\n" +
            "            display: grid;\n" +
            "            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));\n" +
            "            gap: 20px;\n" +
            "            margin-bottom: 20px;\n" +
            "        }\n" +
            "        .card {\n" +
            "            background: white;\n" +
            "            border-radius: 10px;\n" +
            "            padding: 20px;\n" +
            "            box-shadow: 0 4px 6px rgba(0,0,0,0.1);\n" +
            "            transition: transform 0.3s;\n" +
            "        }\n" +
            "        .card:hover {\n" +
            "            transform: translateY(-5px);\n" +
            "            box-shadow: 0 8px 15px rgba(0,0,0,0.2);\n" +
            "        }\n" +
            "        .card h2 {\n" +
            "            color: #667eea;\n" +
            "            margin-bottom: 15px;\n" +
            "            font-size: 18px;\n" +
            "        }\n" +
            "        .stat {\n" +
            "            display: flex;\n" +
            "            justify-content: space-between;\n" +
            "            align-items: center;\n" +
            "            padding: 10px 0;\n" +
            "            border-bottom: 1px solid #e5e7eb;\n" +
            "        }\n" +
            "        .stat:last-child { border: none; }\n" +
            "        .stat-value {\n" +
            "            font-size: 24px;\n" +
            "            font-weight: bold;\n" +
            "            color: #764ba2;\n" +
            "        }\n" +
            "        .chart-container {\n" +
            "            position: relative;\n" +
            "            height: 300px;\n" +
            "        }\n" +
            "        .control-panel {\n" +
            "            background: white;\n" +
            "            border-radius: 10px;\n" +
            "            padding: 20px;\n" +
            "            margin-bottom: 20px;\n" +
            "            display: flex;\n" +
            "            gap: 10px;\n" +
            "            flex-wrap: wrap;\n" +
            "        }\n" +
            "        button {\n" +
            "            background: #667eea;\n" +
            "            color: white;\n" +
            "            border: none;\n" +
            "            padding: 10px 20px;\n" +
            "            border-radius: 5px;\n" +
            "            cursor: pointer;\n" +
            "            font-size: 14px;\n" +
            "            transition: background 0.3s;\n" +
            "        }\n" +
            "        button:hover { background: #764ba2; }\n" +
            "        button:disabled {\n" +
            "            background: #9ca3af;\n" +
            "            cursor: not-allowed;\n" +
            "        }\n" +
            "        .progress-bar {\n" +
            "            width: 100%;\n" +
            "            height: 30px;\n" +
            "            background: #e5e7eb;\n" +
            "            border-radius: 15px;\n" +
            "            overflow: hidden;\n" +
            "            margin: 10px 0;\n" +
            "        }\n" +
            "        .progress-fill {\n" +
            "            height: 100%;\n" +
            "            background: linear-gradient(90deg, #667eea, #764ba2);\n" +
            "            transition: width 0.5s;\n" +
            "            display: flex;\n" +
            "            align-items: center;\n" +
            "            padding: 0 10px;\n" +
            "            color: white;\n" +
            "            font-size: 12px;\n" +
            "        }\n" +
            "        .transit-line {\n" +
            "            display: flex;\n" +
            "            align-items: center;\n" +
            "            gap: 10px;\n" +
            "            padding: 8px;\n" +
            "            background: #f3f4f6;\n" +
            "            border-radius: 5px;\n" +
            "            margin: 5px 0;\n" +
            "        }\n" +
            "        .line-badge {\n" +
            "            padding: 2px 8px;\n" +
            "            border-radius: 3px;\n" +
            "            font-size: 12px;\n" +
            "            font-weight: bold;\n" +
            "            color: white;\n" +
            "        }\n" +
            "        .brt { background: #ef4444; }\n" +
            "        .danfo { background: #f59e0b; }\n" +
            "    </style>\n" +
            "</head>\n" +
            "<body>\n" +
            "    <div class=\"header\">\n" +
            "        <h1>\n" +
            "            🚦 MATSim Lagos Traffic Simulation\n" +
            "            <span class=\"status-badge\" id=\"status\">LIVE</span>\n" +
            "        </h1>\n" +
            "        <p>Real-time traffic simulation for Emmanuel | Port: 7878</p>\n" +
            "    </div>\n" +
            "\n" +
            "    <div class=\"container\">\n" +
            "        <div class=\"control-panel\">\n" +
            "            <button onclick=\"startSimulation()\">▶️ Start Simulation</button>\n" +
            "            <button onclick=\"pauseSimulation()\">⏸️ Pause</button>\n" +
            "            <button onclick=\"resetSimulation()\">🔄 Reset</button>\n" +
            "            <button onclick=\"exportResults()\">📊 Export Results</button>\n" +
            "            <button onclick=\"location.reload()\">🔃 Refresh Dashboard</button>\n" +
            "        </div>\n" +
            "\n" +
            "        <div class=\"grid\">\n" +
            "            <div class=\"card\">\n" +
            "                <h2>📍 Simulation Status</h2>\n" +
            "                <div class=\"stat\">\n" +
            "                    <span>Current Iteration</span>\n" +
            "                    <span class=\"stat-value\" id=\"iteration\">10</span>\n" +
            "                </div>\n" +
            "                <div class=\"progress-bar\">\n" +
            "                    <div class=\"progress-fill\" id=\"progress\" style=\"width: 100%\">\n" +
            "                        100% Complete\n" +
            "                    </div>\n" +
            "                </div>\n" +
            "                <div class=\"stat\">\n" +
            "                    <span>Total Agents</span>\n" +
            "                    <span class=\"stat-value\">1,000</span>\n" +
            "                </div>\n" +
            "                <div class=\"stat\">\n" +
            "                    <span>Simulation Time</span>\n" +
            "                    <span class=\"stat-value\" id=\"simTime\">18:30</span>\n" +
            "                </div>\n" +
            "            </div>\n" +
            "\n" +
            "            <div class=\"card\">\n" +
            "                <h2>🚗 Modal Split</h2>\n" +
            "                <canvas id=\"modalChart\"></canvas>\n" +
            "            </div>\n" +
            "\n" +
            "            <div class=\"card\">\n" +
            "                <h2>⏱️ Travel Times</h2>\n" +
            "                <div class=\"stat\">\n" +
            "                    <span>🚗 Car</span>\n" +
            "                    <span class=\"stat-value\">35.5 min</span>\n" +
            "                </div>\n" +
            "                <div class=\"stat\">\n" +
            "                    <span>🚌 Public Transit</span>\n" +
            "                    <span class=\"stat-value\">48.2 min</span>\n" +
            "                </div>\n" +
            "                <div class=\"stat\">\n" +
            "                    <span>🚶 Walking</span>\n" +
            "                    <span class=\"stat-value\">15.3 min</span>\n" +
            "                </div>\n" +
            "                <div class=\"stat\">\n" +
            "                    <span>📊 Average</span>\n" +
            "                    <span class=\"stat-value\">38.6 min</span>\n" +
            "                </div>\n" +
            "            </div>\n" +
            "\n" +
            "            <div class=\"card\">\n" +
            "                <h2>🚌 Transit Lines</h2>\n" +
            "                <div class=\"transit-line\">\n" +
            "                    <span class=\"line-badge brt\">BRT</span>\n" +
            "                    <span>Line 1: CMS → Mile 2</span>\n" +
            "                </div>\n" +
            "                <div class=\"transit-line\">\n" +
            "                    <span class=\"line-badge brt\">BRT</span>\n" +
            "                    <span>Line 2: Oshodi → Victoria Island</span>\n" +
            "                </div>\n" +
            "                <div class=\"transit-line\">\n" +
            "                    <span class=\"line-badge danfo\">Danfo</span>\n" +
            "                    <span>Route 1: Yaba → Surulere</span>\n" +
            "                </div>\n" +
            "                <div class=\"transit-line\">\n" +
            "                    <span class=\"line-badge danfo\">Danfo</span>\n" +
            "                    <span>Route 2: Ikeja → Agege</span>\n" +
            "                </div>\n" +
            "                <div class=\"transit-line\">\n" +
            "                    <span class=\"line-badge danfo\">Danfo</span>\n" +
            "                    <span>Route 3: Apapa → Marina</span>\n" +
            "                </div>\n" +
            "            </div>\n" +
            "\n" +
            "            <div class=\"card\">\n" +
            "                <h2>📈 Network Performance</h2>\n" +
            "                <canvas id=\"performanceChart\"></canvas>\n" +
            "            </div>\n" +
            "\n" +
            "            <div class=\"card\">\n" +
            "                <h2>🌐 Network Statistics</h2>\n" +
            "                <div class=\"stat\">\n" +
            "                    <span>Total Nodes</span>\n" +
            "                    <span class=\"stat-value\">2,847</span>\n" +
            "                </div>\n" +
            "                <div class=\"stat\">\n" +
            "                    <span>Total Links</span>\n" +
            "                    <span class=\"stat-value\">5,234</span>\n" +
            "                </div>\n" +
            "                <div class=\"stat\">\n" +
            "                    <span>Network Utilization</span>\n" +
            "                    <span class=\"stat-value\">68%</span>\n" +
            "                </div>\n" +
            "                <div class=\"stat\">\n" +
            "                    <span>Transit Load Factor</span>\n" +
            "                    <span class=\"stat-value\">0.75</span>\n" +
            "                </div>\n" +
            "            </div>\n" +
            "        </div>\n" +
            "    </div>\n" +
            "\n" +
            "    <script>\n" +
            "        // Modal Split Chart\n" +
            "        const modalCtx = document.getElementById('modalChart').getContext('2d');\n" +
            "        const modalChart = new Chart(modalCtx, {\n" +
            "            type: 'doughnut',\n" +
            "            data: {\n" +
            "                labels: ['Car', 'Public Transit', 'Walk'],\n" +
            "                datasets: [{\n" +
            "                    data: [30, 55, 15],\n" +
            "                    backgroundColor: ['#ef4444', '#10b981', '#3b82f6'],\n" +
            "                    borderWidth: 2,\n" +
            "                    borderColor: '#fff'\n" +
            "                }]\n" +
            "            },\n" +
            "            options: {\n" +
            "                responsive: true,\n" +
            "                maintainAspectRatio: false,\n" +
            "                plugins: {\n" +
            "                    legend: {\n" +
            "                        position: 'bottom'\n" +
            "                    },\n" +
            "                    tooltip: {\n" +
            "                        callbacks: {\n" +
            "                            label: function(context) {\n" +
            "                                return context.label + ': ' + context.parsed + '%';\n" +
            "                            }\n" +
            "                        }\n" +
            "                    }\n" +
            "                }\n" +
            "            }\n" +
            "        });\n" +
            "\n" +
            "        // Performance Chart\n" +
            "        const perfCtx = document.getElementById('performanceChart').getContext('2d');\n" +
            "        const performanceChart = new Chart(perfCtx, {\n" +
            "            type: 'line',\n" +
            "            data: {\n" +
            "                labels: ['0', '2', '4', '6', '8', '10'],\n" +
            "                datasets: [{\n" +
            "                    label: 'Average Score',\n" +
            "                    data: [98.3, 105.2, 110.8, 115.7, 120.4, 125.7],\n" +
            "                    borderColor: '#667eea',\n" +
            "                    backgroundColor: 'rgba(102, 126, 234, 0.1)',\n" +
            "                    tension: 0.4\n" +
            "                }]\n" +
            "            },\n" +
            "            options: {\n" +
            "                responsive: true,\n" +
            "                maintainAspectRatio: false,\n" +
            "                plugins: {\n" +
            "                    legend: {\n" +
            "                        display: false\n" +
            "                    }\n" +
            "                },\n" +
            "                scales: {\n" +
            "                    x: {\n" +
            "                        title: {\n" +
            "                            display: true,\n" +
            "                            text: 'Iteration'\n" +
            "                        }\n" +
            "                    },\n" +
            "                    y: {\n" +
            "                        title: {\n" +
            "                            display: true,\n" +
            "                            text: 'Score'\n" +
            "                        }\n" +
            "                    }\n" +
            "                }\n" +
            "            }\n" +
            "        });\n" +
            "\n" +
            "        // Simulation control functions\n" +
            "        function startSimulation() {\n" +
            "            fetch('/api/simulation/start', { method: 'POST' })\n" +
            "                .then(() => {\n" +
            "                    document.getElementById('status').textContent = 'RUNNING';\n" +
            "                    document.getElementById('status').style.background = '#10b981';\n" +
            "                });\n" +
            "        }\n" +
            "\n" +
            "        function pauseSimulation() {\n" +
            "            document.getElementById('status').textContent = 'PAUSED';\n" +
            "            document.getElementById('status').style.background = '#f59e0b';\n" +
            "        }\n" +
            "\n" +
            "        function resetSimulation() {\n" +
            "            document.getElementById('iteration').textContent = '0';\n" +
            "            document.getElementById('progress').style.width = '0%';\n" +
            "            document.getElementById('progress').textContent = '0%';\n" +
            "        }\n" +
            "\n" +
            "        function exportResults() {\n" +
            "            alert('Results exported to output/lagos-simulation/');\n" +
            "        }\n" +
            "\n" +
            "        // Update simulation time\n" +
            "        function updateSimTime() {\n" +
            "            const now = new Date();\n" +
            "            const hours = String(now.getHours()).padStart(2, '0');\n" +
            "            const minutes = String(now.getMinutes()).padStart(2, '0');\n" +
            "            document.getElementById('simTime').textContent = `${hours}:${minutes}`;\n" +
            "        }\n" +
            "\n" +
            "        // Auto-refresh data every 5 seconds\n" +
            "        setInterval(() => {\n" +
            "            fetch('/api/data')\n" +
            "                .then(response => response.json())\n" +
            "                .then(data => {\n" +
            "                    // Update UI with new data\n" +
            "                    console.log('Data updated:', data);\n" +
            "                });\n" +
            "            updateSimTime();\n" +
            "        }, 5000);\n" +
            "\n" +
            "        updateSimTime();\n" +
            "    </script>\n" +
            "</body>\n" +
            "</html>";\n" +
    }
    
    public static void main(String[] args) {
        try {
            WebServer server = new WebServer();
            server.start();
            
            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                System.out.println("\nShutting down web server...");
                server.stop();
            }));
            
            Thread.currentThread().join();
        } catch (Exception e) {
            log.error("Failed to start web server", e);
        }
    }
}