package com.emmanuel.matsim.runner;

import org.matsim.core.controler.AbstractModule;
import org.matsim.core.mobsim.qsim.qnetsimengine.QNetworkFactory;
import org.matsim.core.replanning.PlanStrategy;
import org.matsim.core.replanning.PlanStrategyImpl;
import org.matsim.core.replanning.modules.ReRoute;
import org.matsim.core.replanning.modules.TripsToLegsModule;
import org.matsim.core.replanning.selectors.RandomPlanSelector;
import org.matsim.core.router.TripRouter;
import org.matsim.core.router.costcalculators.TravelDisutilityFactory;
import org.matsim.core.router.util.TravelDisutility;
import org.matsim.core.router.util.TravelTime;
import com.google.inject.Inject;
import com.google.inject.Provider;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class LagosSimulationModule extends AbstractModule {
    private static final Logger log = LogManager.getLogger(LagosSimulationModule.class);
    
    @Override
    public void install() {
        log.info("Installing Lagos-specific simulation module");
        
        this.addPlanStrategyBinding("RandomReRoute").toProvider(RandomReRouteProvider.class);
        
        this.addTravelTimeBinding("car").to(LagosCarTravelTime.class);
        
        this.addTravelDisutilityFactoryBinding("car").toInstance(new LagosTravelDisutilityFactory());
        
        log.info("Lagos simulation module installed successfully");
    }
    
    static class RandomReRouteProvider implements Provider<PlanStrategy> {
        @Inject private Provider<TripRouter> tripRouterProvider;
        
        @Override
        public PlanStrategy get() {
            PlanStrategyImpl strategy = new PlanStrategyImpl(new RandomPlanSelector());
            strategy.addStrategyModule(new TripsToLegsModule(tripRouterProvider, null));
            strategy.addStrategyModule(new ReRoute(null, tripRouterProvider, null, null));
            return strategy;
        }
    }
    
    static class LagosCarTravelTime implements TravelTime {
        @Override
        public double getLinkTravelTime(org.matsim.api.core.v01.network.Link link, 
                                       double time, 
                                       org.matsim.api.core.v01.population.Person person, 
                                       org.matsim.vehicles.Vehicle vehicle) {
            double freeSpeedTravelTime = link.getLength() / link.getFreespeed();
            
            double congestionFactor = 1.0;
            if (time >= 7 * 3600 && time <= 10 * 3600) {
                congestionFactor = 2.5;
            } else if (time >= 17 * 3600 && time <= 20 * 3600) {
                congestionFactor = 2.8;
            } else if (time >= 10 * 3600 && time <= 17 * 3600) {
                congestionFactor = 1.5;
            }
            
            return freeSpeedTravelTime * congestionFactor;
        }
    }
    
    static class LagosTravelDisutilityFactory implements TravelDisutilityFactory {
        @Override
        public TravelDisutility createTravelDisutility(TravelTime travelTime) {
            return new LagosTravelDisutility(travelTime);
        }
    }
    
    static class LagosTravelDisutility implements TravelDisutility {
        private final TravelTime travelTime;
        private static final double MARGINAL_COST_OF_TIME = 12.0 / 3600;
        private static final double MARGINAL_COST_OF_DISTANCE = 0.0003;
        
        public LagosTravelDisutility(TravelTime travelTime) {
            this.travelTime = travelTime;
        }
        
        @Override
        public double getLinkTravelDisutility(org.matsim.api.core.v01.network.Link link, 
                                             double time, 
                                             org.matsim.api.core.v01.population.Person person, 
                                             org.matsim.vehicles.Vehicle vehicle) {
            double travelTimeSeconds = travelTime.getLinkTravelTime(link, time, person, vehicle);
            double distanceMeters = link.getLength();
            
            double disutility = travelTimeSeconds * MARGINAL_COST_OF_TIME + 
                               distanceMeters * MARGINAL_COST_OF_DISTANCE;
            
            if (link.getFreespeed() < 30.0 / 3.6) {
                disutility *= 1.2;
            }
            
            return disutility;
        }
        
        @Override
        public double getLinkMinimumTravelDisutility(org.matsim.api.core.v01.network.Link link) {
            return link.getLength() / link.getFreespeed() * MARGINAL_COST_OF_TIME + 
                   link.getLength() * MARGINAL_COST_OF_DISTANCE;
        }
    }
}