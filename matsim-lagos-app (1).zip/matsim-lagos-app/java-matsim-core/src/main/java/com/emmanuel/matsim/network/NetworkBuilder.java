package com.emmanuel.matsim.network;

import org.matsim.api.core.v01.Coord;
import org.matsim.api.core.v01.Scenario;
import org.matsim.api.core.v01.network.Network;
import org.matsim.api.core.v01.network.NetworkWriter;
import org.matsim.contrib.osm.networkReader.LinkProperties;
import org.matsim.contrib.osm.networkReader.SupersonicOsmNetworkReader;
import org.matsim.core.config.Config;
import org.matsim.core.config.ConfigUtils;
import org.matsim.core.network.algorithms.NetworkCleaner;
import org.matsim.core.scenario.ScenarioUtils;
import org.matsim.core.utils.geometry.CoordinateTransformation;
import org.matsim.core.utils.geometry.transformations.TransformationFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.HashSet;
import java.util.Set;

public class NetworkBuilder {
    private static final Logger log = LogManager.getLogger(NetworkBuilder.class);
    private static final String CRS_LAGOS = "EPSG:32631";
    private final String osmFile;
    private final String outputNetworkFile;
    private Network network;
    
    public NetworkBuilder(String osmFile, String outputNetworkFile) {
        this.osmFile = osmFile;
        this.outputNetworkFile = outputNetworkFile;
    }
    
    public void buildNetwork() {
        log.info("Starting network construction for Lagos from OSM data...");
        
        Config config = ConfigUtils.createConfig();
        Scenario scenario = ScenarioUtils.createScenario(config);
        network = scenario.getNetwork();
        
        CoordinateTransformation transformation = TransformationFactory
                .getCoordinateTransformation(TransformationFactory.WGS84, CRS_LAGOS);
        
        SupersonicOsmNetworkReader osmReader = new SupersonicOsmNetworkReader.Builder()
                .setCoordinateTransformation(transformation)
                .setIncludeLinkAtCoordWithHierarchy((Coord coord, int hierarchyLevel) -> {
                    return hierarchyLevel >= 4;
                })
                .setAfterLinkCreated((link, osm, isReverse) -> {
                    Set<String> modes = new HashSet<>();
                    modes.add("car");
                    modes.add("bus");
                    modes.add("walk");
                    link.setAllowedModes(modes);
                })
                .build();
        
        osmReader.read(osmFile);
        
        new NetworkCleaner().run(network);
        
        log.info("Network built with {} nodes and {} links", 
                network.getNodes().size(), network.getLinks().size());
    }
    
    public void writeNetwork() {
        if (network == null) {
            throw new IllegalStateException("Network must be built before writing");
        }
        
        NetworkWriter networkWriter = new NetworkWriter(network);
        networkWriter.write(outputNetworkFile);
        log.info("Network written to: {}", outputNetworkFile);
    }
    
    public Network getNetwork() {
        return network;
    }
    
    public static class LagosLinkProperties {
        public static LinkProperties getLinkProperties() {
            LinkProperties linkProperties = new LinkProperties(9, 1, 1.0, 1800, 1.0, 0);
            
            linkProperties.setProperties(1, "motorway", 2, 120.0 / 3.6, 1.0, 2000);
            linkProperties.setProperties(1, "motorway_link", 1, 80.0 / 3.6, 1.0, 1500);
            linkProperties.setProperties(2, "trunk", 1, 80.0 / 3.6, 1.0, 2000);
            linkProperties.setProperties(2, "trunk_link", 1, 50.0 / 3.6, 1.0, 1500);
            linkProperties.setProperties(3, "primary", 1, 60.0 / 3.6, 1.0, 1500);
            linkProperties.setProperties(3, "primary_link", 1, 40.0 / 3.6, 1.0, 1500);
            linkProperties.setProperties(4, "secondary", 1, 50.0 / 3.6, 1.0, 1000);
            linkProperties.setProperties(5, "tertiary", 1, 40.0 / 3.6, 1.0, 600);
            linkProperties.setProperties(6, "residential", 1, 30.0 / 3.6, 1.0, 600);
            linkProperties.setProperties(7, "living_street", 1, 15.0 / 3.6, 1.0, 300);
            linkProperties.setProperties(8, "pedestrian", 1, 15.0 / 3.6, 1.0, 300);
            linkProperties.setProperties(9, "unclassified", 1, 30.0 / 3.6, 1.0, 600);
            
            return linkProperties;
        }
    }
}