package com.emmanuel.matsim.ml;

import java.util.*;
import java.time.LocalDateTime;
import java.time.DayOfWeek;

/**
 * Machine Learning Traffic Predictor for Lagos
 * Predicts traffic patterns and congestion levels
 */
public class TrafficPredictor {
    
    private Map<String, Double> historicalData;
    private Map<String, TrafficPattern> patterns;
    
    public TrafficPredictor() {
        this.historicalData = new HashMap<>();
        this.patterns = new HashMap<>();
        initializePatterns();
    }
    
    /**
     * Predict traffic congestion level for a specific location and time
     * @return congestion level (0-10, where 10 is "everywhere don cast")
     */
    public PredictionResult predictTraffic(String location, LocalDateTime dateTime) {
        double baseCongestion = getBaselineTraffic(location, dateTime);
        double weatherImpact = getWeatherImpact(dateTime);
        double eventImpact = getEventImpact(location, dateTime);
        double dayPattern = getDayOfWeekPattern(dateTime.getDayOfWeek());
        
        double totalCongestion = baseCongestion * (1 + weatherImpact) * (1 + eventImpact) * dayPattern;
        totalCongestion = Math.min(10, Math.max(0, totalCongestion));
        
        String description = getCongestionDescription(totalCongestion);
        String advice = getTrafficAdvice(totalCongestion, location);
        
        return new PredictionResult(location, dateTime, totalCongestion, description, advice);
    }
    
    private void initializePatterns() {
        // Lagos traffic patterns
        patterns.put("third_mainland", new TrafficPattern(7.5, 6, 10, 16, 21));
        patterns.put("lekki_epe", new TrafficPattern(8.0, 6, 11, 17, 22));
        patterns.put("oshodi", new TrafficPattern(9.0, 5, 23, 0, 0)); // Always busy
        patterns.put("victoria_island", new TrafficPattern(7.0, 7, 10, 17, 20));
        patterns.put("ikeja", new TrafficPattern(7.5, 6, 10, 16, 21));
        patterns.put("apapa", new TrafficPattern(8.5, 5, 22, 0, 0)); // Port traffic
    }
    
    private double getBaselineTraffic(String location, LocalDateTime dateTime) {
        int hour = dateTime.getHour();
        TrafficPattern pattern = patterns.getOrDefault(location.toLowerCase(), 
                                                        new TrafficPattern(5.0, 7, 10, 17, 20));
        
        // Morning rush
        if (hour >= pattern.morningRushStart && hour <= pattern.morningRushEnd) {
            return pattern.baseLevel * 1.5;
        }
        // Evening rush
        if (hour >= pattern.eveningRushStart && hour <= pattern.eveningRushEnd) {
            return pattern.baseLevel * 1.8;
        }
        // Night time
        if (hour < 5 || hour > 22) {
            return pattern.baseLevel * 0.3;
        }
        // Normal hours
        return pattern.baseLevel;
    }
    
    private double getWeatherImpact(LocalDateTime dateTime) {
        // Rainy season (April - October) in Lagos
        int month = dateTime.getMonthValue();
        if (month >= 4 && month <= 10) {
            // Simulate 30% chance of rain
            if (Math.random() < 0.3) {
                return 0.5; // 50% increase in traffic during rain
            }
        }
        return 0.0;
    }
    
    private double getEventImpact(String location, LocalDateTime dateTime) {
        DayOfWeek day = dateTime.getDayOfWeek();
        
        // Friday prayers impact
        if (day == DayOfWeek.FRIDAY && dateTime.getHour() >= 12 && dateTime.getHour() <= 14) {
            return 0.3;
        }
        
        // Sunday church impact
        if (day == DayOfWeek.SUNDAY && dateTime.getHour() >= 8 && dateTime.getHour() <= 12) {
            return 0.4;
        }
        
        // Market day (Wednesday & Saturday)
        if ((day == DayOfWeek.WEDNESDAY || day == DayOfWeek.SATURDAY) && 
            location.toLowerCase().contains("market")) {
            return 0.6;
        }
        
        return 0.0;
    }
    
    private double getDayOfWeekPattern(DayOfWeek day) {
        switch (day) {
            case MONDAY: return 1.2;  // Terrible Monday traffic
            case FRIDAY: return 1.3;  // TGIF rush
            case SATURDAY: return 0.9; // Owambe traffic
            case SUNDAY: return 0.6;   // Light traffic
            default: return 1.0;
        }
    }
    
    private String getCongestionDescription(double level) {
        if (level <= 2) return "Road dey free like bird";
        if (level <= 4) return "Small small traffic dey";
        if (level <= 6) return "E dey somehow o";
        if (level <= 8) return "Everywhere don dey red";
        return "Everywhere don cast! Stay house if you fit";
    }
    
    private String getTrafficAdvice(double level, String location) {
        if (level <= 3) {
            return "You fit move now, road dey okay";
        } else if (level <= 6) {
            return "Try use alternative route or wait small";
        } else if (level <= 8) {
            return "If no be urgent matter, abeg wait. Consider Uber boat for Island";
        } else {
            return "Oga, just siddon for house today. Tomorrow go better";
        }
    }
    
    /**
     * Train the model with historical data
     */
    public void trainModel(List<HistoricalDataPoint> dataPoints) {
        for (HistoricalDataPoint point : dataPoints) {
            String key = point.location + "_" + point.hour + "_" + point.dayOfWeek;
            historicalData.put(key, point.congestionLevel);
        }
    }
    
    /**
     * Get traffic hotspots for current time
     */
    public List<TrafficHotspot> getCurrentHotspots() {
        List<TrafficHotspot> hotspots = new ArrayList<>();
        LocalDateTime now = LocalDateTime.now();
        
        for (String location : patterns.keySet()) {
            PredictionResult prediction = predictTraffic(location, now);
            if (prediction.congestionLevel > 7) {
                hotspots.add(new TrafficHotspot(location, prediction.congestionLevel, 
                                               prediction.description));
            }
        }
        
        hotspots.sort((a, b) -> Double.compare(b.congestionLevel, a.congestionLevel));
        return hotspots;
    }
    
    // Inner classes
    static class TrafficPattern {
        double baseLevel;
        int morningRushStart, morningRushEnd;
        int eveningRushStart, eveningRushEnd;
        
        TrafficPattern(double base, int mStart, int mEnd, int eStart, int eEnd) {
            this.baseLevel = base;
            this.morningRushStart = mStart;
            this.morningRushEnd = mEnd;
            this.eveningRushStart = eStart;
            this.eveningRushEnd = eEnd;
        }
    }
    
    public static class PredictionResult {
        public final String location;
        public final LocalDateTime dateTime;
        public final double congestionLevel;
        public final String description;
        public final String advice;
        
        PredictionResult(String location, LocalDateTime dateTime, double congestionLevel,
                        String description, String advice) {
            this.location = location;
            this.dateTime = dateTime;
            this.congestionLevel = congestionLevel;
            this.description = description;
            this.advice = advice;
        }
    }
    
    public static class TrafficHotspot {
        public final String location;
        public final double congestionLevel;
        public final String description;
        
        TrafficHotspot(String location, double congestionLevel, String description) {
            this.location = location;
            this.congestionLevel = congestionLevel;
            this.description = description;
        }
    }
    
    public static class HistoricalDataPoint {
        public final String location;
        public final int hour;
        public final DayOfWeek dayOfWeek;
        public final double congestionLevel;
        
        public HistoricalDataPoint(String location, int hour, DayOfWeek day, double level) {
            this.location = location;
            this.hour = hour;
            this.dayOfWeek = day;
            this.congestionLevel = level;
        }
    }
}