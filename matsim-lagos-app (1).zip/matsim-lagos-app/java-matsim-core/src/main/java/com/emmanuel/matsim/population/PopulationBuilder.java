package com.emmanuel.matsim.population;

import org.matsim.api.core.v01.Coord;
import org.matsim.api.core.v01.Id;
import org.matsim.api.core.v01.Scenario;
import org.matsim.api.core.v01.TransportMode;
import org.matsim.api.core.v01.network.Network;
import org.matsim.api.core.v01.population.*;
import org.matsim.core.config.Config;
import org.matsim.core.gbl.MatsimRandom;
import org.matsim.core.population.io.PopulationWriter;
import org.matsim.core.utils.geometry.CoordinateTransformation;
import org.matsim.core.utils.geometry.transformations.TransformationFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Random;

public class PopulationBuilder {
    private static final Logger log = LogManager.getLogger(PopulationBuilder.class);
    private final Scenario scenario;
    private final Population population;
    private final PopulationFactory populationFactory;
    private final Random random = MatsimRandom.getRandom();
    
    private static final double MIN_LON = 3.2;
    private static final double MAX_LON = 3.6;
    private static final double MIN_LAT = 6.35;
    private static final double MAX_LAT = 6.7;
    
    private static final String CRS_LAGOS = "EPSG:32631";
    private final CoordinateTransformation ct;
    
    public PopulationBuilder(Scenario scenario) {
        this.scenario = scenario;
        this.population = scenario.getPopulation();
        this.populationFactory = population.getFactory();
        this.ct = TransformationFactory.getCoordinateTransformation(
                TransformationFactory.WGS84, CRS_LAGOS);
    }
    
    public void createPopulation(int numberOfAgents) {
        log.info("Creating population of {} agents for Lagos simulation", numberOfAgents);
        
        for (int i = 0; i < numberOfAgents; i++) {
            createAgent(i);
        }
        
        log.info("Population created with {} agents", population.getPersons().size());
    }
    
    private void createAgent(int agentId) {
        Person person = populationFactory.createPerson(Id.createPersonId("agent_" + agentId));
        Plan plan = populationFactory.createPlan();
        
        Coord homeCoord = generateRandomCoord();
        Coord workCoord = generateRandomCoord();
        Coord marketCoord = generateRandomCoord();
        Coord schoolCoord = generateRandomCoord();
        
        String mode = selectTransportMode();
        
        double homeTime = 6.0 * 3600 + random.nextDouble() * 2 * 3600;
        Activity homeActivity1 = populationFactory.createActivityFromCoord("home", homeCoord);
        homeActivity1.setEndTime(homeTime);
        plan.addActivity(homeActivity1);
        
        Leg legToWork = populationFactory.createLeg(mode);
        plan.addLeg(legToWork);
        
        double workTime = homeTime + 30 * 60 + random.nextDouble() * 60 * 60;
        Activity workActivity = populationFactory.createActivityFromCoord("work", workCoord);
        workActivity.setStartTime(workTime);
        workActivity.setEndTime(workTime + 8 * 3600);
        plan.addActivity(workActivity);
        
        if (random.nextDouble() < 0.5) {
            Leg legToMarket = populationFactory.createLeg(mode);
            plan.addLeg(legToMarket);
            
            Activity marketActivity = populationFactory.createActivityFromCoord("market", marketCoord);
            marketActivity.setMaximumDuration(60 * 60);
            plan.addActivity(marketActivity);
        }
        
        if (random.nextDouble() < 0.3) {
            Leg legToSchool = populationFactory.createLeg(mode);
            plan.addLeg(legToSchool);
            
            Activity schoolActivity = populationFactory.createActivityFromCoord("school", schoolCoord);
            schoolActivity.setMaximumDuration(90 * 60);
            plan.addActivity(schoolActivity);
        }
        
        Leg legToHome = populationFactory.createLeg(mode);
        plan.addLeg(legToHome);
        
        Activity homeActivity2 = populationFactory.createActivityFromCoord("home", homeCoord);
        plan.addActivity(homeActivity2);
        
        person.addPlan(plan);
        person.setSelectedPlan(plan);
        
        PersonUtils.setAge(person, 20 + random.nextInt(45));
        PersonUtils.setSex(person, random.nextBoolean() ? "m" : "f");
        PersonUtils.setEmployed(person, random.nextDouble() < 0.7);
        PersonUtils.setCarAvail(person, mode.equals(TransportMode.car) ? "always" : "never");
        
        population.addPerson(person);
    }
    
    private Coord generateRandomCoord() {
        double lon = MIN_LON + random.nextDouble() * (MAX_LON - MIN_LON);
        double lat = MIN_LAT + random.nextDouble() * (MAX_LAT - MIN_LAT);
        return ct.transform(new Coord(lon, lat));
    }
    
    private String selectTransportMode() {
        double rand = random.nextDouble();
        if (rand < 0.3) {
            return TransportMode.car;
        } else if (rand < 0.8) {
            return TransportMode.pt;
        } else {
            return TransportMode.walk;
        }
    }
    
    public void writePopulation(String outputFile) {
        PopulationWriter populationWriter = new PopulationWriter(population);
        populationWriter.write(outputFile);
        log.info("Population written to: {}", outputFile);
    }
    
    public static class ActivityTimings {
        public static final double HOME_START = 6.0 * 3600;
        public static final double HOME_END_VARIATION = 2.0 * 3600;
        public static final double WORK_DURATION = 8.0 * 3600;
        public static final double MARKET_DURATION = 1.0 * 3600;
        public static final double SCHOOL_DURATION = 1.5 * 3600;
        public static final double TRAVEL_TIME = 0.5 * 3600;
    }
    
    public static class AgentProfile {
        private final String id;
        private final String primaryMode;
        private final boolean hasWork;
        private final boolean hasSchool;
        private final boolean hasMarket;
        
        public AgentProfile(String id, String primaryMode, boolean hasWork, boolean hasSchool, boolean hasMarket) {
            this.id = id;
            this.primaryMode = primaryMode;
            this.hasWork = hasWork;
            this.hasSchool = hasSchool;
            this.hasMarket = hasMarket;
        }
        
        public String getId() { return id; }
        public String getPrimaryMode() { return primaryMode; }
        public boolean hasWork() { return hasWork; }
        public boolean hasSchool() { return hasSchool; }
        public boolean hasMarket() { return hasMarket; }
    }
}