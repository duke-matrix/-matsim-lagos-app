#!/bin/bash

echo "========================================"
echo "MATSim Lagos Traffic Simulation"
echo "========================================"
echo

# Function to show usage
show_usage() {
    echo "ERROR: No parameters provided!"
    echo
    echo "Usage: ./run-simulation.sh [REQUIRED] [OPTIONS]"
    echo
    echo "REQUIRED PARAMETERS:"
    echo "  --population SIZE    Number of agents to simulate (e.g., 10000)"
    echo "  --iterations COUNT   Number of iterations (e.g., 100)"
    echo
    echo "OPTIONAL PARAMETERS:"
    echo "  --output DIR         Output directory (default: output)"
    echo "  --enable-okada       Enable Okada motorcycle mode"
    echo "  --enable-weather     Enable weather impact modeling"
    echo "  --threads COUNT      Number of threads (default: 4)"
    echo "  --mode TYPE          Simulation mode: FULL, QUICK, or TEST"
    echo "  --config FILE        Custom configuration file"
    echo
    echo "EXAMPLES:"
    echo "  ./run-simulation.sh --population 5000 --iterations 50"
    echo "  ./run-simulation.sh --population 10000 --iterations 100 --enable-okada"
    echo "  ./run-simulation.sh --config myconfig.properties"
    echo
    echo "ENVIRONMENT VARIABLES (optional):"
    echo "  export MATSIM_SIMULATION_POPULATION_SIZE=10000"
    echo "  export MATSIM_SIMULATION_ITERATIONS=100"
    echo "  export MATSIM_LAGOS_ENABLE_OKADA=true"
    echo
    exit 1
}

# Check if help is requested or no params
if [ $# -eq 0 ] || [ "$1" == "-h" ] || [ "$1" == "--help" ]; then
    show_usage
fi

# Check if Java is available
if ! command -v java &> /dev/null; then
    echo "ERROR: Java not found. Please install Java 11 or higher."
    exit 1
fi

# Check if JAR exists, build if not
JAR_FILE="target/matsim-lagos-app-1.0.0-jar-with-dependencies.jar"
if [ ! -f "$JAR_FILE" ]; then
    echo "Building application..."
    if command -v mvn &> /dev/null; then
        mvn clean package -DskipTests
        if [ $? -ne 0 ]; then
            echo "Build failed!"
            exit 1
        fi
    else
        echo "ERROR: Maven not found. Please install Maven or use pre-built JAR."
        exit 1
    fi
fi

# Run simulation with parameters
echo "Starting simulation with parameters:"
echo "$@"
echo

java -Xmx4g -jar "$JAR_FILE" "$@"