"""
Lagos Traffic API - RESTful API for third-party integration
Provides real-time traffic data, predictions, and routing
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
from datetime import datetime, timedelta
import random
import json

app = Flask(__name__)
CORS(app)

# Simulated data store
traffic_data = {}
incidents = []

@app.route('/api/v1/status', methods=['GET'])
def api_status():
    """API health check"""
    return jsonify({
        'status': 'online',
        'version': '1.0.0',
        'service': 'Lagos Traffic Wahala API',
        'timestamp': datetime.now().isoformat()
    })

@app.route('/api/v1/traffic/current', methods=['GET'])
def get_current_traffic():
    """Get current traffic conditions across Lagos"""
    locations = [
        {'name': 'Third Mainland Bridge', 'congestion': 7.5, 'speed': 25},
        {'name': 'Lekki-Epe Expressway', 'congestion': 6.8, 'speed': 35},
        {'name': 'Oshodi', 'congestion': 9.2, 'speed': 10},
        {'name': 'Victoria Island', 'congestion': 5.5, 'speed': 40},
        {'name': 'Ikeja', 'congestion': 7.0, 'speed': 30},
        {'name': 'Apapa', 'congestion': 8.9, 'speed': 15}
    ]
    
    for loc in locations:
        loc['status'] = get_status_description(loc['congestion'])
        loc['updated'] = datetime.now().isoformat()
    
    return jsonify({
        'success': True,
        'data': locations,
        'summary': {
            'average_congestion': sum(l['congestion'] for l in locations) / len(locations),
            'worst_location': max(locations, key=lambda x: x['congestion'])['name'],
            'best_location': min(locations, key=lambda x: x['congestion'])['name']
        }
    })

@app.route('/api/v1/traffic/location/<location>', methods=['GET'])
def get_location_traffic(location):
    """Get traffic for specific location"""
    congestion = random.uniform(3, 9)
    
    return jsonify({
        'success': True,
        'location': location,
        'data': {
            'congestion_level': round(congestion, 1),
            'average_speed': int(60 - (congestion * 5)),
            'status': get_status_description(congestion),
            'travel_time_multiplier': 1 + (congestion / 10),
            'description': get_pidgin_description(congestion),
            'advice': get_traffic_advice(congestion),
            'updated': datetime.now().isoformat()
        }
    })

@app.route('/api/v1/traffic/predict', methods=['POST'])
def predict_traffic():
    """Predict future traffic conditions"""
    data = request.json
    location = data.get('location', 'Lagos')
    hours_ahead = data.get('hours_ahead', 1)
    
    future_time = datetime.now() + timedelta(hours=hours_ahead)
    hour = future_time.hour
    
    # Simple prediction based on time of day
    if 6 <= hour <= 10 or 16 <= hour <= 20:
        congestion = random.uniform(7, 9)
    elif 10 < hour < 16:
        congestion = random.uniform(4, 6)
    else:
        congestion = random.uniform(2, 4)
    
    return jsonify({
        'success': True,
        'prediction': {
            'location': location,
            'time': future_time.isoformat(),
            'predicted_congestion': round(congestion, 1),
            'confidence': random.uniform(0.7, 0.95),
            'factors': ['time_of_day', 'historical_pattern', 'day_of_week'],
            'recommendation': get_traffic_advice(congestion)
        }
    })

@app.route('/api/v1/routes/optimal', methods=['POST'])
def get_optimal_route():
    """Get optimal route between two points"""
    data = request.json
    origin = data.get('origin')
    destination = data.get('destination')
    
    routes = [
        {
            'name': 'Fastest Route',
            'distance': random.uniform(10, 30),
            'duration': random.randint(25, 60),
            'congestion': random.uniform(3, 7),
            'via': ['Ozumba Mbadiwe', 'Lekki-Epe Expressway'],
            'toll_gates': 1,
            'fuel_cost_estimate': random.randint(500, 1500)
        },
        {
            'name': 'Alternative Route',
            'distance': random.uniform(12, 35),
            'duration': random.randint(30, 70),
            'congestion': random.uniform(4, 8),
            'via': ['Third Mainland Bridge', 'Western Avenue'],
            'toll_gates': 0,
            'fuel_cost_estimate': random.randint(600, 1700)
        }
    ]
    
    return jsonify({
        'success': True,
        'origin': origin,
        'destination': destination,
        'routes': routes,
        'recommendation': routes[0],
        'water_transport_available': destination in ['Victoria Island', 'Ikoyi'],
        'generated_at': datetime.now().isoformat()
    })

@app.route('/api/v1/incidents', methods=['GET'])
def get_incidents():
    """Get current traffic incidents"""
    incidents = [
        {
            'id': 'INC001',
            'type': 'accident',
            'location': 'Third Mainland Bridge',
            'description': 'Multiple vehicle collision',
            'severity': 'high',
            'lanes_blocked': 2,
            'estimated_clear_time': '2 hours',
            'reported_at': datetime.now().isoformat()
        },
        {
            'id': 'INC002',
            'type': 'breakdown',
            'location': 'Oshodi',
            'description': 'Trailer breakdown at interchange',
            'severity': 'medium',
            'lanes_blocked': 1,
            'estimated_clear_time': '45 minutes',
            'reported_at': datetime.now().isoformat()
        }
    ]
    
    return jsonify({
        'success': True,
        'total_incidents': len(incidents),
        'incidents': incidents
    })

@app.route('/api/v1/incidents/report', methods=['POST'])
def report_incident():
    """Report a new traffic incident"""
    data = request.json
    
    incident = {
        'id': f'INC{random.randint(1000, 9999)}',
        'type': data.get('type'),
        'location': data.get('location'),
        'description': data.get('description'),
        'severity': data.get('severity', 'medium'),
        'reporter': data.get('reporter', 'anonymous'),
        'reported_at': datetime.now().isoformat(),
        'status': 'pending_verification'
    }
    
    incidents.append(incident)
    
    return jsonify({
        'success': True,
        'message': 'Incident reported successfully',
        'incident_id': incident['id'],
        'data': incident
    }), 201

@app.route('/api/v1/analytics/summary', methods=['GET'])
def get_analytics_summary():
    """Get traffic analytics summary"""
    return jsonify({
        'success': True,
        'period': 'last_24_hours',
        'analytics': {
            'total_vehicles': random.randint(100000, 200000),
            'average_speed': random.randint(25, 40),
            'peak_congestion': {
                'time': '08:30',
                'level': 8.7,
                'location': 'Oshodi'
            },
            'modal_split': {
                'private_cars': 30,
                'danfo_brt': 55,
                'walking': 10,
                'okada_keke': 5
            },
            'busiest_routes': [
                'Third Mainland Bridge',
                'Lekki-Epe Expressway',
                'Oshodi-Apapa Expressway'
            ],
            'average_commute_time': 48.5,
            'emissions_estimate': {
                'co2_tons': random.randint(500, 1000),
                'comparison': 'Equivalent to 50,000 trees needed'
            }
        }
    })

@app.route('/api/v1/transport/alternatives', methods=['GET'])
def get_transport_alternatives():
    """Get alternative transport options"""
    lat = request.args.get('lat', 6.5244)
    lng = request.args.get('lng', 3.3792)
    
    return jsonify({
        'success': True,
        'location': {'lat': lat, 'lng': lng},
        'alternatives': [
            {
                'type': 'BRT',
                'nearest_stop': 'CMS Bus Stop',
                'distance': '500m',
                'next_arrival': '5 minutes',
                'fare': 300
            },
            {
                'type': 'Ferry',
                'nearest_terminal': 'CMS Jetty',
                'distance': '800m',
                'next_departure': '15 minutes',
                'fare': 500
            },
            {
                'type': 'Uber/Bolt',
                'availability': 'high',
                'estimated_fare': 2500,
                'wait_time': '3 minutes'
            },
            {
                'type': 'Okada',
                'availability': 'very high',
                'estimated_fare': 200,
                'safety_rating': 2.5
            }
        ]
    })

@app.route('/api/v1/subscribe/alerts', methods=['POST'])
def subscribe_alerts():
    """Subscribe to traffic alerts"""
    data = request.json
    
    subscription = {
        'id': f'SUB{random.randint(10000, 99999)}',
        'email': data.get('email'),
        'phone': data.get('phone'),
        'routes': data.get('routes', []),
        'alert_types': data.get('alert_types', ['incidents', 'congestion']),
        'frequency': data.get('frequency', 'real-time'),
        'created_at': datetime.now().isoformat()
    }
    
    return jsonify({
        'success': True,
        'message': 'Successfully subscribed to traffic alerts',
        'subscription': subscription
    }), 201

# Helper functions
def get_status_description(congestion):
    if congestion < 3:
        return 'free_flow'
    elif congestion < 6:
        return 'moderate'
    elif congestion < 8:
        return 'heavy'
    else:
        return 'gridlock'

def get_pidgin_description(congestion):
    if congestion < 3:
        return 'Road dey kampe, you fit fly'
    elif congestion < 6:
        return 'Small hold-up dey, but e no too bad'
    elif congestion < 8:
        return 'Everywhere dey red o, find another way'
    else:
        return 'Everywhere don cast! No even try am'

def get_traffic_advice(congestion):
    if congestion < 4:
        return 'Good time to travel'
    elif congestion < 7:
        return 'Consider alternative routes or wait 30 minutes'
    else:
        return 'Avoid travel if possible, or use water transport'

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)