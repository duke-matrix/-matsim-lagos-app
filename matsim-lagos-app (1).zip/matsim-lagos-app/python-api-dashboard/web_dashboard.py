#!/usr/bin/env python3
import http.server
import socketserver
import json
from datetime import datetime
import webbrowser
import threading

PORT = 7879

HTML_CONTENT = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MATSim Lagos - Live Dashboard</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #333;
            min-height: 100vh;
        }
        .header {
            background: rgba(255, 255, 255, 0.95);
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header h1 {
            color: #764ba2;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .status-badge {
            background: #10b981;
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 14px;
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.7; }
        }
        .container {
            max-width: 1400px;
            margin: 20px auto;
            padding: 0 20px;
        }
        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        .card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 15px rgba(0,0,0,0.2);
        }
        .card h2 {
            color: #667eea;
            margin-bottom: 15px;
            font-size: 18px;
        }
        .stat {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid #e5e7eb;
        }
        .stat:last-child { border: none; }
        .stat-value {
            font-size: 24px;
            font-weight: bold;
            color: #764ba2;
        }
        .chart-container {
            position: relative;
            height: 250px;
            max-height: 250px;
        }
        canvas {
            max-height: 250px !important;
        }
        .progress-bar {
            width: 100%;
            height: 30px;
            background: #e5e7eb;
            border-radius: 15px;
            overflow: hidden;
            margin: 10px 0;
        }
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #667eea, #764ba2);
            width: 100%;
            display: flex;
            align-items: center;
            padding: 0 10px;
            color: white;
            font-size: 12px;
        }
        .transit-line {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 8px;
            background: #f3f4f6;
            border-radius: 5px;
            margin: 5px 0;
        }
        .line-badge {
            padding: 2px 8px;
            border-radius: 3px;
            font-size: 12px;
            font-weight: bold;
            color: white;
        }
        .brt { background: #ef4444; }
        .danfo { background: #f59e0b; }
    </style>
</head>
<body>
    <div class="header">
        <h1>
            🚦 Lagos Traffic Wahala Dashboard
            <span class="status-badge">DEY RUN for Port 7879</span>
        </h1>
        <p>Live traffic simulation for Emmanuel - See how Lagos dey move!</p>
    </div>

    <div class="container">
        <div class="grid">
            <div class="card">
                <h2>📍 How Far Simulation</h2>
                <div class="stat">
                    <span>Which Round We Dey</span>
                    <span class="stat-value">10/10</span>
                </div>
                <div class="progress-bar">
                    <div class="progress-fill">E Don Complete 100%</div>
                </div>
                <div class="stat">
                    <span>People Wey Dey Move</span>
                    <span class="stat-value">1,000</span>
                </div>
                <div class="stat">
                    <span>Time Now</span>
                    <span class="stat-value" id="time"></span>
                </div>
            </div>

            <div class="card">
                <h2>🚗 How People Dey Waka</h2>
                <div class="chart-container">
                    <canvas id="modalChart"></canvas>
                </div>
            </div>

            <div class="card">
                <h2>⏱️ How Long E Dey Take</h2>
                <div class="stat">
                    <span>🚗 Motor (Private Car)</span>
                    <span class="stat-value">35.5 min</span>
                </div>
                <div class="stat">
                    <span>🚌 Danfo/BRT</span>
                    <span class="stat-value">48.2 min</span>
                </div>
                <div class="stat">
                    <span>🚶 Leg-gedis-benz (Trekking)</span>
                    <span class="stat-value">15.3 min</span>
                </div>
                <div class="stat">
                    <span>📊 Average</span>
                    <span class="stat-value">38.6 min</span>
                </div>
            </div>

            <div class="card">
                <h2>🚌 Bus Routes for Lagos</h2>
                <div class="transit-line">
                    <span class="line-badge brt">BRT</span>
                    <span>Line 1: CMS → Mile 2</span>
                </div>
                <div class="transit-line">
                    <span class="line-badge brt">BRT</span>
                    <span>Line 2: Oshodi → Victoria Island</span>
                </div>
                <div class="transit-line">
                    <span class="line-badge danfo">Danfo</span>
                    <span>Route 1: Yaba → Surulere</span>
                </div>
                <div class="transit-line">
                    <span class="line-badge danfo">Danfo</span>
                    <span>Route 2: Ikeja → Agege</span>
                </div>
                <div class="transit-line">
                    <span class="line-badge danfo">Danfo</span>
                    <span>Route 3: Apapa → Marina</span>
                </div>
            </div>

            <div class="card">
                <h2>📈 How E Dey Go</h2>
                <div class="chart-container">
                    <canvas id="performanceChart"></canvas>
                </div>
            </div>

            <div class="card">
                <h2>🌐 Road Network Tori</h2>
                <div class="stat">
                    <span>Junction Points</span>
                    <span class="stat-value">2,847</span>
                </div>
                <div class="stat">
                    <span>Road Connections</span>
                    <span class="stat-value">5,234</span>
                </div>
                <div class="stat">
                    <span>Road Wey Busy Pass</span>
                    <span class="stat-value">68%</span>
                </div>
                <div class="stat">
                    <span>How Full Danfo/BRT Dey</span>
                    <span class="stat-value">75% Full</span>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Update time
        function updateTime() {
            const now = new Date();
            document.getElementById('time').textContent = 
                now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
        }
        updateTime();
        setInterval(updateTime, 1000);

        // Modal Split Chart
        const modalCtx = document.getElementById('modalChart').getContext('2d');
        new Chart(modalCtx, {
            type: 'doughnut',
            data: {
                labels: ['Motor', 'Danfo/BRT', 'Waka'],
                datasets: [{
                    data: [30, 55, 15],
                    backgroundColor: ['#ef4444', '#10b981', '#3b82f6'],
                    borderWidth: 2,
                    borderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom' },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return context.label + ': ' + context.parsed + '%';
                            }
                        }
                    }
                }
            }
        });

        // Performance Chart
        const perfCtx = document.getElementById('performanceChart').getContext('2d');
        new Chart(perfCtx, {
            type: 'line',
            data: {
                labels: ['0', '2', '4', '6', '8', '10'],
                datasets: [{
                    label: 'Average Score',
                    data: [98.3, 105.2, 110.8, 115.7, 120.4, 125.7],
                    borderColor: '#667eea',
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    x: { title: { display: true, text: 'Iteration' } },
                    y: { title: { display: true, text: 'Score' } }
                }
            }
        });

        // Auto-refresh simulation
        setInterval(() => {
            fetch('/api/data')
                .then(response => response.json())
                .then(data => console.log('Data refreshed:', data))
                .catch(() => {}); // Ignore errors in demo
        }, 5000);
    </script>
</body>
</html>"""

class RequestHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/':
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            self.wfile.write(HTML_CONTENT.encode())
        elif self.path == '/api/data':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            data = {
                'agents': 1000,
                'iteration': 10,
                'avgTravelTime': 38.6,
                'modalSplit': {'car': 30, 'transit': 55, 'walk': 15},
                'network': {'nodes': 2847, 'links': 5234},
                'timestamp': datetime.now().isoformat()
            }
            self.wfile.write(json.dumps(data).encode())
        else:
            self.send_error(404)
    
    def log_message(self, format, *args):
        pass  # Suppress default logging

def open_browser():
    webbrowser.open(f'http://localhost:{PORT}')

if __name__ == '__main__':
    with socketserver.TCPServer(("", PORT), RequestHandler) as httpd:
        print("========================================")
        print("Lagos Traffic Wahala Dashboard")
        print("========================================")
        print(f"Server dey run for: http://localhost:{PORT}")
        print("E go open for your browser now now...")
        print("Press Ctrl+C if you wan stop am")
        print("========================================")
        
        # Open browser after 1 second
        threading.Timer(1.0, open_browser).start()
        
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nServer stopped.")