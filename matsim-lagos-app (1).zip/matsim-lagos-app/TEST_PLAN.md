# Test Plan for MATSim Lagos Application

This document outlines the testing strategy for the MATSim Lagos Application, encompassing both the Java MATSim core and the Python API/dashboard components. The goal is to ensure the reliability, correctness, and performance of the simulation and its associated services.

## 1. Java MATSim Core Testing (JUnit)

### 1.1 Unit Tests

**Purpose:** To verify the correctness of individual classes and methods within the Java MATSim core. This includes components like `NetworkBuilder`, `PopulationBuilder`, `TransitBuilder`, `ConfigBuilder`, and other utility or model classes.

**Framework:** JUnit 5

**Location:** `java-matsim-core/src/test/java/com/emmanuel/matsim/`

**Execution:**

```bash
cd java-matsim-core
mvn test
```

**Coverage:** Unit tests should aim for high code coverage, focusing on critical logic, edge cases, and data transformations.

### 1.2 Integration Tests

**Purpose:** To ensure that different modules of the Java MATSim core interact correctly. This might involve testing the full simulation setup process, including network loading, population generation, and configuration application, before running the actual simulation.

**Framework:** JUnit 5 (potentially with MATSim's own testing utilities)

**Location:** Integrated within the `java-matsim-core` test suite, or in a dedicated `integration` package if complexity warrants.

**Execution:** Included in `mvn test` or a separate Maven profile if they are long-running.

## 2. Python API and Dashboard Testing (Pytest)

### 2.1 Unit Tests

**Purpose:** To verify the functionality of individual Python functions and classes in the API and dashboard. This includes data processing logic, API endpoint handlers, and dashboard utility functions.

**Framework:** Pytest

**Location:** `python-api-dashboard/tests/unit/`

**Execution:**

```bash
cd python-api-dashboard
pytest tests/unit/
```

**Coverage:** Focus on core logic, data parsing, and API request/response handling.

### 2.2 Integration Tests

**Purpose:** To ensure that the Python API and dashboard interact correctly with each other and potentially with the Java MATSim core (e.g., reading simulation outputs). This includes testing API endpoints, data visualization components, and overall application flow.

**Framework:** Pytest (with `requests` for API calls, `selenium` or `playwright` for UI tests if applicable).

**Location:** `python-api-dashboard/tests/integration/`

**Execution:**

```bash
cd python-api-dashboard
pytest tests/integration/
```

**Coverage:** End-to-end scenarios, API contract validation, and critical user flows in the dashboard.

## 3. Docker Smoke Test

**Purpose:** To verify that the Docker image builds successfully and that the essential services (Java MATSim application, Python API/dashboard) start up and are accessible within the container.

**Framework:** `curl` or similar command-line tools within the CI/CD pipeline.

**Location:** Defined in `.github/workflows/ci.yml`

**Execution:** Automatically triggered as part of the CI/CD pipeline.

**Checks:**
*   Docker image build success.
*   Container starts without errors.
*   Python web dashboard is reachable via HTTP (e.g., `curl http://localhost:5000`).
*   (Optional) If Java MATSim exposes an API, verify its accessibility.

## 4. CI/CD Integration

All tests (Java JUnit, Python Pytest, and Docker Smoke Test) are integrated into the GitHub Actions workflow (`.github/workflows/ci.yml`). This ensures that every push to `main` and every pull request automatically triggers the test suite, providing continuous feedback on code quality and functionality.

## 5. Future Enhancements

*   Implement more comprehensive UI tests for the web dashboard.
*   Add performance tests for both Java simulation and Python API.
*   Integrate code quality checks (e.g., SonarQube for Java, Pylint/Flake8 for Python).
*   Automate simulation result validation against expected benchmarks.
